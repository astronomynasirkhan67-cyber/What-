package com.pakchat.app

import com.pakchat.app.util.PhoneNumberValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PhoneNumberValidatorTest {

    @Test
    fun normalizePakistaniNumber_formatsCorrectly() {
        val result1 = PhoneNumberValidator.normalizePakistaniNumber("03001234567")
        assertEquals("+923001234567", result1)

        val result2 = PhoneNumberValidator.normalizePakistaniNumber("3001234567")
        assertEquals("+923001234567", result2)

        val result3 = PhoneNumberValidator.normalizePakistaniNumber("+923001234567")
        assertEquals("+923001234567", result3)

        val result4 = PhoneNumberValidator.normalizePakistaniNumber("0345-9876543")
        assertEquals("+923459876543", result4)
    }

    @Test
    fun isValidPakistaniNumber_validatesMobileNumbers() {
        assertTrue(PhoneNumberValidator.isValidPakistaniNumber("+923001234567"))
        assertTrue(PhoneNumberValidator.isValidPakistaniNumber("+923459876543"))
        assertTrue(PhoneNumberValidator.isValidPakistaniNumber("+923120000000"))

        assertFalse(PhoneNumberValidator.isValidPakistaniNumber("+92211234567")) // landline
        assertFalse(PhoneNumberValidator.isValidPakistaniNumber("03001234567")) // not normalized
        assertFalse(PhoneNumberValidator.isValidPakistaniNumber("+14155552671")) // US number
    }

    @Test
    fun formatForDisplay_formatsReadableSpaces() {
        val formatted = PhoneNumberValidator.formatForDisplay("+923001234567")
        assertEquals("+92 300 1234567", formatted)
    }
}
