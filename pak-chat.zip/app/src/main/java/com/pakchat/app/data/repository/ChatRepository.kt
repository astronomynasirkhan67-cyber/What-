package com.pakchat.app.data.repository

import android.net.Uri
import android.util.Log
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import com.pakchat.app.model.Chat
import com.pakchat.app.model.Message
import com.pakchat.app.model.MessageStatus
import com.pakchat.app.model.MessageType
import com.pakchat.app.model.User
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.io.File
import java.util.UUID

class ChatRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val storage: FirebaseStorage = FirebaseStorage.getInstance()
) {

    private val chatsCollection = firestore.collection("chats")

    fun getOneToOneChatId(uid1: String, uid2: String): String {
        return if (uid1 < uid2) "chat_${uid1}_${uid2}" else "chat_${uid2}_${uid1}"
    }

    suspend fun getOrCreateOneToOneChat(currentUser: User, targetUser: User): String {
        val chatId = getOneToOneChatId(currentUser.uid, targetUser.uid)
        val chatRef = chatsCollection.document(chatId)

        try {
            val doc = chatRef.get().await()
            if (!doc.exists()) {
                val newChat = Chat(
                    chatId = chatId,
                    participants = listOf(currentUser.uid, targetUser.uid),
                    participantNames = mapOf(
                        currentUser.uid to currentUser.displayName,
                        targetUser.uid to targetUser.displayName
                    ),
                    participantPhotos = mapOf(
                        currentUser.uid to currentUser.photoUrl,
                        targetUser.uid to targetUser.photoUrl
                    ),
                    participantPhones = mapOf(
                        currentUser.uid to currentUser.phoneNumber,
                        targetUser.uid to targetUser.phoneNumber
                    ),
                    lastMessage = "Chat started",
                    lastMessageTimestamp = System.currentTimeMillis(),
                    lastMessageSenderId = currentUser.uid,
                    lastMessageType = MessageType.SYSTEM.name,
                    unreadCounts = mapOf(
                        currentUser.uid to 0,
                        targetUser.uid to 0
                    )
                )
                chatRef.set(newChat).await()
            } else {
                // Update participant metadata if changed
                chatRef.update(
                    mapOf(
                        "participantNames.${currentUser.uid}" to currentUser.displayName,
                        "participantPhotos.${currentUser.uid}" to currentUser.photoUrl,
                        "participantPhones.${currentUser.uid}" to currentUser.phoneNumber,
                        "participantNames.${targetUser.uid}" to targetUser.displayName,
                        "participantPhotos.${targetUser.uid}" to targetUser.photoUrl,
                        "participantPhones.${targetUser.uid}" to targetUser.phoneNumber
                    )
                ).await()
            }
        } catch (e: Exception) {
            Log.e("ChatRepository", "Error ensuring chat document exists", e)
        }

        return chatId
    }

    fun getUserChatsFlow(currentUserId: String): Flow<List<Chat>> = callbackFlow {
        val listener = chatsCollection
            .whereArrayContains("participants", currentUserId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("ChatRepository", "Error observing user chats", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }

                val chats = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(Chat::class.java)
                }?.sortedByDescending { it.lastMessageTimestamp } ?: emptyList()

                trySend(chats)
            }

        awaitClose { listener.remove() }
    }

    fun getChatMessagesFlow(chatId: String, limit: Long = 100): Flow<List<Message>> = callbackFlow {
        val messagesRef = chatsCollection.document(chatId).collection("messages")
        val listener = messagesRef
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .limitToLast(limit)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("ChatRepository", "Error observing messages for $chatId", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }

                val messages = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(Message::class.java)
                } ?: emptyList()

                trySend(messages)
            }

        awaitClose { listener.remove() }
    }

    suspend fun sendMessage(message: Message): Result<Unit> {
        return try {
            val messageId = if (message.messageId.isBlank()) UUID.randomUUID().toString() else message.messageId
            val finalMessage = message.copy(messageId = messageId)

            val chatRef = chatsCollection.document(message.chatId)
            val messageRef = chatRef.collection("messages").document(messageId)

            firestore.runBatch { batch ->
                batch.set(messageRef, finalMessage)

                val previewText = when (message.messageType) {
                    MessageType.IMAGE.name -> "📷 Photo"
                    MessageType.VOICE.name -> "🎤 Voice message"
                    MessageType.VIDEO.name -> "🎥 Video"
                    MessageType.DOCUMENT.name -> "📄 Document"
                    else -> message.text
                }

                val updates = mutableMapOf<String, Any>(
                    "lastMessage" to previewText,
                    "lastMessageTimestamp" to message.timestamp,
                    "lastMessageSenderId" to message.senderId,
                    "lastMessageType" to message.messageType,
                    "unreadCounts.${message.receiverId}" to FieldValue.increment(1)
                )

                batch.update(chatRef, updates)
            }.await()

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("ChatRepository", "Failed to send message", e)
            Result.failure(e)
        }
    }

    suspend fun markChatAsRead(chatId: String, currentUserId: String) {
        try {
            // Reset unread counter for current user in chat doc
            val chatRef = chatsCollection.document(chatId)
            chatRef.update("unreadCounts.$currentUserId", 0).await()

            // Update unread incoming messages to READ
            val messagesRef = chatRef.collection("messages")
            val unreadDocs = messagesRef
                .whereEqualTo("receiverId", currentUserId)
                .whereNotEqualTo("status", MessageStatus.READ.name)
                .limit(50)
                .get()
                .await()

            if (!unreadDocs.isEmpty) {
                firestore.runBatch { batch ->
                    for (doc in unreadDocs.documents) {
                        batch.update(doc.reference, "status", MessageStatus.READ.name)
                    }
                }.await()
            }
        } catch (e: Exception) {
            Log.e("ChatRepository", "Failed to mark chat as read", e)
        }
    }

    suspend fun setTypingStatus(chatId: String, userId: String, isTyping: Boolean) {
        try {
            chatsCollection.document(chatId).update("typing.$userId", isTyping).await()
        } catch (e: Exception) {
            Log.e("ChatRepository", "Failed to set typing status", e)
        }
    }

    suspend fun addReaction(chatId: String, messageId: String, userId: String, emoji: String) {
        try {
            val messageRef = chatsCollection.document(chatId).collection("messages").document(messageId)
            messageRef.update("reactions.$userId", emoji).await()
        } catch (e: Exception) {
            Log.e("ChatRepository", "Failed to add reaction", e)
        }
    }

    suspend fun starMessage(chatId: String, messageId: String, isStarred: Boolean) {
        try {
            val messageRef = chatsCollection.document(chatId).collection("messages").document(messageId)
            messageRef.update("isStarred", isStarred).await()
        } catch (e: Exception) {
            Log.e("ChatRepository", "Failed to star message", e)
        }
    }

    suspend fun deleteForEveryone(chatId: String, messageId: String) {
        try {
            val messageRef = chatsCollection.document(chatId).collection("messages").document(messageId)
            messageRef.update(
                mapOf(
                    "deletedForEveryone" to true,
                    "text" to "This message was deleted"
                )
            ).await()
        } catch (e: Exception) {
            Log.e("ChatRepository", "Failed to delete message for everyone", e)
        }
    }

    suspend fun deleteForMe(chatId: String, messageId: String, userId: String) {
        try {
            val messageRef = chatsCollection.document(chatId).collection("messages").document(messageId)
            messageRef.update("deletedForUsers", FieldValue.arrayUnion(userId)).await()
        } catch (e: Exception) {
            Log.e("ChatRepository", "Failed to delete message for me", e)
        }
    }

    suspend fun editMessage(chatId: String, messageId: String, newText: String) {
        try {
            val messageRef = chatsCollection.document(chatId).collection("messages").document(messageId)
            messageRef.update(
                mapOf(
                    "text" to newText,
                    "isEdited" to true
                )
            ).await()
        } catch (e: Exception) {
            Log.e("ChatRepository", "Failed to edit message", e)
        }
    }

    suspend fun forwardMessage(targetChatId: String, targetReceiverId: String, currentUserId: String, originalMessage: Message): Result<Unit> {
        val forwardMsg = originalMessage.copy(
            messageId = UUID.randomUUID().toString(),
            senderId = currentUserId,
            receiverId = targetReceiverId,
            chatId = targetChatId,
            timestamp = System.currentTimeMillis(),
            status = MessageStatus.SENT.name,
            replyToId = null,
            replyToText = null,
            replyToSenderName = null,
            reactions = emptyMap(),
            isStarred = false,
            deletedForEveryone = false,
            deletedForUsers = emptyList()
        )
        return sendMessage(forwardMsg)
    }

    suspend fun uploadChatMedia(chatId: String, file: File, extension: String): Result<String> {
        return try {
            val fileName = "${UUID.randomUUID()}.$extension"
            val ref = storage.reference.child("chat_media/$chatId/$fileName")
            ref.putFile(Uri.fromFile(file)).await()
            val downloadUrl = ref.downloadUrl.await().toString()
            Result.success(downloadUrl)
        } catch (e: Exception) {
            Log.e("ChatRepository", "Failed to upload chat media", e)
            Result.failure(e)
        }
    }
}
