package com.pakchat.app.model

data class StatusItem(
    val statusId: String = "",
    val userId: String = "",
    val userDisplayName: String = "",
    val userPhotoUrl: String = "",
    val type: String = "TEXT", // TEXT, IMAGE
    val content: String = "",
    val mediaUrl: String = "",
    val backgroundColor: Long = 0xFF006A4E,
    val timestamp: Long = System.currentTimeMillis(),
    val viewedBy: List<String> = emptyList()
) {
    fun isExpired(): Boolean {
        // Status expires after 24 hours (86,400,000 ms)
        return (System.currentTimeMillis() - timestamp) > 24 * 60 * 60 * 1000L
    }
}
