package com.pakchat.app.ui.screens.chat

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Reply
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Forward
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SentimentSatisfiedAlt
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.pakchat.app.data.repository.UserRepository
import com.pakchat.app.model.Message
import com.pakchat.app.model.MessageType
import com.pakchat.app.model.User
import com.pakchat.app.ui.components.EmojiPickerSheet
import com.pakchat.app.ui.components.MessageStatusIcon
import com.pakchat.app.ui.components.QuickEmojiReactionsRow
import com.pakchat.app.ui.components.UserAvatar
import com.pakchat.app.ui.theme.PakDarkBackground
import com.pakchat.app.ui.theme.PakEmeraldGreen
import com.pakchat.app.ui.theme.PakGrayText
import com.pakchat.app.ui.theme.PakIncomingBubbleLight
import com.pakchat.app.ui.theme.PakLightTeal
import com.pakchat.app.ui.theme.PakMintBubble
import com.pakchat.app.ui.theme.PakSurfaceDark
import com.pakchat.app.ui.viewmodel.ChatViewModel
import com.pakchat.app.util.TimeUtils
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToCall: (otherUserId: String, isVideo: Boolean) -> Unit,
    onNavigateToGroupInfo: (groupId: String) -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val userRepository = remember { UserRepository() }

    val otherUser by viewModel.otherUser.collectAsState()
    val group by viewModel.group.collectAsState()
    val groupMembers by viewModel.groupMembers.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val inputText by viewModel.inputText.collectAsState()
    val replyingTo by viewModel.replyingTo.collectAsState()
    val selectedMessage by viewModel.selectedMessage.collectAsState()
    val selectedMessageIds by viewModel.selectedMessageIds.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isRecordingVoice by viewModel.isRecordingVoice.collectAsState()
    val recordingDuration by viewModel.recordingDurationSeconds.collectAsState()
    val isUploadingMedia by viewModel.isUploadingMedia.collectAsState()
    val uploadProgress by viewModel.uploadProgress.collectAsState()
    val pendingMedia by viewModel.pendingMedia.collectAsState()
    val editingMessage by viewModel.editingMessage.collectAsState()

    val isPlaying by viewModel.audioPlayer.isPlaying.collectAsState()
    val currentPlayingId by viewModel.audioPlayer.currentPlayingId.collectAsState()
    val audioProgress by viewModel.audioPlayer.progress.collectAsState()

    var showEmojiPicker by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showAttachmentMenu by remember { mutableStateOf(false) }
    var showForwardDialog by remember { mutableStateOf(false) }
    var forwardTargetMessage by remember { mutableStateOf<Message?>(null) }
    val allForwardUsers by userRepository.getAllUsersFlow(viewModel.currentUserId).collectAsState(initial = emptyList())

    val listState = rememberLazyListState()

    // Auto-scroll to latest message when messages change
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
            viewModel.markAsRead()
        }
    }

    // Media Pickers
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val tempFile = File(context.cacheDir, "chat_img_${System.currentTimeMillis()}.jpg")
                val outputStream = FileOutputStream(tempFile)
                inputStream?.copyTo(outputStream)
                inputStream?.close()
                outputStream.close()
                viewModel.setPendingMedia(tempFile, MessageType.IMAGE)
            } catch (e: Exception) {
                Toast.makeText(context, "Could not open image: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val tempFile = File(context.cacheDir, "chat_vid_${System.currentTimeMillis()}.mp4")
                val outputStream = FileOutputStream(tempFile)
                inputStream?.copyTo(outputStream)
                inputStream?.close()
                outputStream.close()
                viewModel.setPendingMedia(tempFile, MessageType.VIDEO)
            } catch (e: Exception) {
                Toast.makeText(context, "Could not open video: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                var displayName = "document.pdf"
                context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1) displayName = cursor.getString(nameIndex)
                    }
                }
                val inputStream = context.contentResolver.openInputStream(uri)
                val tempFile = File(context.cacheDir, displayName)
                val outputStream = FileOutputStream(tempFile)
                inputStream?.copyTo(outputStream)
                inputStream?.close()
                outputStream.close()
                viewModel.setPendingMedia(tempFile, MessageType.DOCUMENT, originalName = displayName)
            } catch (e: Exception) {
                Toast.makeText(context, "Could not open document: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Scaffold(
        topBar = {
            if (selectedMessageIds.isNotEmpty()) {
                // Multi-select Action Bar
                TopAppBar(
                    title = {
                        Text(
                            text = "${selectedMessageIds.size} selected",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { viewModel.clearSelection() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Clear", tint = Color.White)
                        }
                    },
                    actions = {
                        IconButton(onClick = {
                            val selectedText = messages.filter { selectedMessageIds.contains(it.messageId) }
                                .joinToString("\n") { it.text }
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Pak Chat messages", selectedText))
                            Toast.makeText(context, "Messages copied", Toast.LENGTH_SHORT).show()
                            viewModel.clearSelection()
                        }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = Color.White)
                        }
                        IconButton(onClick = { viewModel.deleteSelectedForMe() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = PakEmeraldGreen)
                )
            } else if (isSearching) {
                // Search Top Bar
                TopAppBar(
                    title = {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.setSearchQuery(it) },
                            placeholder = { Text("Search messages...", color = Color.White.copy(alpha = 0.7f)) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = { viewModel.toggleSearching() }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Close Search", tint = Color.White)
                        }
                    },
                    actions = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(onClick = { viewModel.setSearchQuery("") }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.White)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = PakEmeraldGreen)
                )
            } else {
                // Standard Top Bar
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (viewModel.isGroup) {
                                        onNavigateToGroupInfo(viewModel.chatId)
                                    }
                                }
                        ) {
                            if (viewModel.isGroup) {
                                if (!group?.iconUrl.isNullOrBlank()) {
                                    AsyncImage(
                                        model = group?.iconUrl,
                                        contentDescription = "Group Icon",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(Color.White.copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Group, contentDescription = null, tint = Color.White)
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = group?.name ?: "Group Chat",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 17.sp,
                                        color = Color.White,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${groupMembers.size} participants",
                                        fontSize = 12.sp,
                                        color = Color.White.copy(alpha = 0.8f)
                                    )
                                }
                            } else {
                                UserAvatar(
                                    photoUrl = otherUser?.photoUrl,
                                    displayName = otherUser?.displayName ?: "Pak Chat User",
                                    size = 40.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = otherUser?.displayName ?: "Pak Chat User",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 17.sp,
                                        color = Color.White,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val isOnline = otherUser?.isOnline == true
                                    val lastSeenText = TimeUtils.formatLastSeen(otherUser?.lastSeen ?: 0L, isOnline)
                                    Text(
                                        text = lastSeenText,
                                        fontSize = 12.sp,
                                        color = if (isOnline) Color(0xFFC8E6C9) else Color.White.copy(alpha = 0.8f)
                                    )
                                }
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    actions = {
                        if (!viewModel.isGroup) {
                            IconButton(onClick = { onNavigateToCall(viewModel.otherUserId, true) }) {
                                Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = Color.White)
                            }
                            IconButton(onClick = { onNavigateToCall(viewModel.otherUserId, false) }) {
                                Icon(Icons.Default.Call, contentDescription = "Audio Call", tint = Color.White)
                            }
                        }
                        IconButton(onClick = { viewModel.toggleSearching() }) {
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.White)
                        }
                        IconButton(onClick = { showMenu = !showMenu }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More", tint = Color.White)
                        }

                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            if (viewModel.isGroup) {
                                DropdownMenuItem(
                                    text = { Text("Group info") },
                                    onClick = {
                                        showMenu = false
                                        onNavigateToGroupInfo(viewModel.chatId)
                                    }
                                )
                            } else {
                                DropdownMenuItem(
                                    text = { Text("Search messages") },
                                    onClick = {
                                        showMenu = false
                                        viewModel.toggleSearching()
                                    }
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = PakEmeraldGreen)
                )
            }
        },
        bottomBar = {
            val isRestricted = viewModel.isGroup && group?.onlyAdminsCanMessage == true && group?.isAdmin(viewModel.currentUserId) == false

            if (isRestricted) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PakSurfaceDark)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Only admins can send messages in this group",
                        color = PakGrayText,
                        fontSize = 13.sp
                    )
                }
            } else {
                Column {
                    // Reply Preview
                    AnimatedVisibility(visible = replyingTo != null) {
                        val reply = replyingTo
                        if (reply != null) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(horizontal = 16.dp, vertical = 8.dp)
                                        .fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(4.dp)
                                            .height(36.dp)
                                            .background(PakEmeraldGreen, RoundedCornerShape(2.dp))
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (reply.senderId == viewModel.currentUserId) "You" else reply.replyToSenderName ?: "User",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = PakEmeraldGreen
                                        )
                                        Text(
                                            text = reply.text,
                                            fontSize = 13.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    IconButton(onClick = { viewModel.setReplyingTo(null) }) {
                                        Icon(Icons.Default.Close, contentDescription = "Cancel reply", modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }

                    // Upload progress
                    if (isUploadingMedia) {
                        LinearProgressIndicator(
                            progress = { uploadProgress },
                            modifier = Modifier.fillMaxWidth(),
                            color = PakLightTeal
                        )
                    }

                    // Chat Input Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isRecordingVoice) {
                            // Voice Recording UI
                            Surface(
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surface,
                                shadowElevation = 2.dp,
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(Color.Red)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = TimeUtils.formatDuration(recordingDuration),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    Spacer(modifier = Modifier.weight(1f))
                                    Text(
                                        text = "Recording...",
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            IconButton(
                                onClick = { viewModel.cancelVoiceRecording() },
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Cancel", tint = MaterialTheme.colorScheme.error)
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            IconButton(
                                onClick = { viewModel.stopAndSendVoiceRecording() },
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(PakLightTeal)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send voice note", tint = Color.White)
                            }

                        } else {
                            // Regular Message Input Bar
                            Surface(
                                shape = RoundedCornerShape(24.dp),
                                color = MaterialTheme.colorScheme.surface,
                                shadowElevation = 1.dp,
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(onClick = { showEmojiPicker = !showEmojiPicker }) {
                                        Icon(
                                            Icons.Default.SentimentSatisfiedAlt,
                                            contentDescription = "Emojis",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    OutlinedTextField(
                                        value = inputText,
                                        onValueChange = { viewModel.onInputTextChanged(it) },
                                        placeholder = { Text("Message") },
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = Color.Transparent,
                                            unfocusedBorderColor = Color.Transparent
                                        ),
                                        maxLines = 5,
                                        modifier = Modifier.weight(1f)
                                    )

                                    Box {
                                        IconButton(onClick = { showAttachmentMenu = true }) {
                                            Icon(
                                                Icons.Default.AttachFile,
                                                contentDescription = "Attach media",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        DropdownMenu(
                                            expanded = showAttachmentMenu,
                                            onDismissRequest = { showAttachmentMenu = false }
                                        ) {
                                            DropdownMenuItem(
                                                text = { Text("📷 Photo") },
                                                onClick = {
                                                    showAttachmentMenu = false
                                                    photoPickerLauncher.launch(
                                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                    )
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("🎥 Video") },
                                                onClick = {
                                                    showAttachmentMenu = false
                                                    videoPickerLauncher.launch(
                                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                                    )
                                                }
                                            )
                                            DropdownMenuItem(
                                                text = { Text("📄 Document / File") },
                                                onClick = {
                                                    showAttachmentMenu = false
                                                    documentPickerLauncher.launch(arrayOf("*/*"))
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            if (inputText.isNotBlank()) {
                                IconButton(
                                    onClick = { viewModel.sendTextMessage() },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(PakLightTeal)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                                }
                            } else {
                                IconButton(
                                    onClick = { viewModel.startVoiceRecording(context) },
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(PakLightTeal)
                                ) {
                                    Icon(Icons.Default.Mic, contentDescription = "Voice note", tint = Color.White)
                                }
                            }
                        }
                    }

                    if (showEmojiPicker) {
                        EmojiPickerSheet(
                            onEmojiPicked = { emoji ->
                                viewModel.onInputTextChanged(inputText + emoji)
                            },
                            modifier = Modifier.height(260.dp)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        // Chat Canvas
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFEFEAE2))
        ) {
            val filteredMessages = if (searchQuery.isNotBlank()) {
                messages.filter { it.text.contains(searchQuery, ignoreCase = true) }
            } else {
                messages
            }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                var lastDate = ""
                items(filteredMessages, key = { it.messageId }) { message ->
                    if (!message.deletedForUsers.contains(viewModel.currentUserId)) {
                        val messageDate = TimeUtils.formatDateHeader(message.timestamp)
                        if (messageDate != lastDate) {
                            lastDate = messageDate
                            DateChipHeader(dateText = messageDate)
                        }

                        val isSelected = selectedMessageIds.contains(message.messageId)

                        MessageBubbleItem(
                            message = message,
                            isOutgoing = message.senderId == viewModel.currentUserId,
                            isPlaying = isPlaying && currentPlayingId == message.messageId,
                            audioProgress = if (currentPlayingId == message.messageId) audioProgress else 0f,
                            isSelected = isSelected,
                            onPlayAudio = {
                                if (message.mediaUrl != null) {
                                    viewModel.audioPlayer.playAudio(message.messageId, message.mediaUrl)
                                }
                            },
                            onLongPress = {
                                if (selectedMessageIds.isNotEmpty()) {
                                    viewModel.toggleSelectMessage(message.messageId)
                                } else {
                                    viewModel.selectMessage(message)
                                }
                            },
                            onClick = {
                                if (selectedMessageIds.isNotEmpty()) {
                                    viewModel.toggleSelectMessage(message.messageId)
                                }
                            }
                        )
                    }
                }
            }
        }

        // Message Options Bottom Sheet
        val msg = selectedMessage
        if (msg != null) {
            val isMyMsg = msg.senderId == viewModel.currentUserId
            val sheetState = rememberModalBottomSheetState()

            ModalBottomSheet(
                onDismissRequest = { viewModel.selectMessage(null) },
                sheetState = sheetState
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 24.dp)
                ) {
                    QuickEmojiReactionsRow(
                        onEmojiSelected = { emoji ->
                            viewModel.addReaction(msg, emoji)
                        },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    DropdownMenuItem(
                        text = { Text("Reply") },
                        leadingIcon = { Icon(Icons.AutoMirrored.Filled.Reply, contentDescription = null) },
                        onClick = {
                            viewModel.setReplyingTo(msg)
                            viewModel.selectMessage(null)
                        }
                    )

                    DropdownMenuItem(
                        text = { Text("Forward") },
                        leadingIcon = { Icon(Icons.Default.Forward, contentDescription = null) },
                        onClick = {
                            forwardTargetMessage = msg
                            showForwardDialog = true
                            viewModel.selectMessage(null)
                        }
                    )

                    if (isMyMsg && msg.messageType == MessageType.TEXT.name && !msg.deletedForEveryone) {
                        DropdownMenuItem(
                            text = { Text("Edit") },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                            onClick = {
                                viewModel.setEditingMessage(msg)
                                viewModel.selectMessage(null)
                            }
                        )
                    }

                    DropdownMenuItem(
                        text = { Text("Copy text") },
                        leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null) },
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Pak Chat message", msg.text))
                            Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                            viewModel.selectMessage(null)
                        }
                    )

                    DropdownMenuItem(
                        text = { Text(if (msg.isStarred) "Unstar" else "Star") },
                        leadingIcon = { Icon(Icons.Default.Star, contentDescription = null) },
                        onClick = {
                            viewModel.starMessage(msg)
                        }
                    )

                    DropdownMenuItem(
                        text = { Text("Delete for me") },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                        onClick = {
                            viewModel.deleteForMe(msg)
                        }
                    )

                    if (isMyMsg && !msg.deletedForEveryone) {
                        DropdownMenuItem(
                            text = { Text("Delete for everyone", color = MaterialTheme.colorScheme.error) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                            onClick = {
                                viewModel.deleteForEveryone(msg)
                            }
                        )
                    }
                }
            }
        }

        // Media Preview Dialog
        if (pendingMedia != null) {
            MediaPreviewDialog(
                pendingMedia = pendingMedia!!,
                onDismiss = { viewModel.clearPendingMedia() },
                onSend = { caption ->
                    viewModel.sendPendingMedia(caption)
                }
            )
        }

        // Edit Message Dialog
        if (editingMessage != null) {
            val target = editingMessage!!
            var newText by remember { mutableStateOf(target.text) }

            AlertDialog(
                onDismissRequest = { viewModel.setEditingMessage(null) },
                title = { Text("Edit Message") },
                text = {
                    OutlinedTextField(
                        value = newText,
                        onValueChange = { newText = it },
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    TextButton(onClick = { viewModel.saveEditedMessage(newText) }) {
                        Text("Save", color = PakEmeraldGreen)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.setEditingMessage(null) }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Forward Message Dialog
        if (showForwardDialog && forwardTargetMessage != null) {
            AlertDialog(
                onDismissRequest = {
                    showForwardDialog = false
                    forwardTargetMessage = null
                },
                title = { Text("Forward to...") },
                text = {
                    LazyColumn(modifier = Modifier.fillMaxWidth()) {
                        items(allForwardUsers) { user ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        val targetChatId = "chat_${listOf(viewModel.currentUserId, user.uid).sorted().joinToString("_")}"
                                        viewModel.forwardMessage(targetChatId, user.uid, forwardTargetMessage!!)
                                        Toast.makeText(context, "Forwarded to ${user.displayName}", Toast.LENGTH_SHORT).show()
                                        showForwardDialog = false
                                        forwardTargetMessage = null
                                    }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                UserAvatar(photoUrl = user.photoUrl, displayName = user.displayName, size = 36.dp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(user.displayName, fontWeight = FontWeight.Medium, fontSize = 15.sp)
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = {
                        showForwardDialog = false
                        forwardTargetMessage = null
                    }) {
                        Text("Cancel", color = PakEmeraldGreen)
                    }
                }
            )
        }
    }
}

@Composable
fun DateChipHeader(dateText: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = Color(0xDCFFFFFF),
            shadowElevation = 1.dp
        ) {
            Text(
                text = dateText,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = Color.DarkGray,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun MessageBubbleItem(
    message: Message,
    isOutgoing: Boolean,
    isPlaying: Boolean,
    audioProgress: Float,
    isSelected: Boolean = false,
    onPlayAudio: () -> Unit,
    onLongPress: () -> Unit,
    onClick: () -> Unit = {}
) {
    val bubbleColor = if (isOutgoing) PakMintBubble else PakIncomingBubbleLight
    val bubbleShape = if (isOutgoing) {
        RoundedCornerShape(topStart = 16.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
    } else {
        RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isSelected) PakEmeraldGreen.copy(alpha = 0.15f) else Color.Transparent)
            .padding(vertical = 3.dp),
        contentAlignment = if (isOutgoing) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Card(
            shape = bubbleShape,
            colors = CardDefaults.cardColors(containerColor = bubbleColor),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier
                .widthIn(min = 60.dp, max = 300.dp)
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = onLongPress
                )
        ) {
            Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                // Quoted Reply (if replying to another message)
                if (!message.replyToText.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color.Black.copy(alpha = 0.06f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 4.dp)
                    ) {
                        Row(modifier = Modifier.padding(6.dp)) {
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(28.dp)
                                    .background(PakEmeraldGreen)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = message.replyToSenderName ?: "User",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = PakEmeraldGreen
                                )
                                Text(
                                    text = message.replyToText,
                                    fontSize = 11.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                // Image Media Message
                if (message.messageType == MessageType.IMAGE.name && !message.mediaUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = message.mediaUrl,
                        contentDescription = "Sent image",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }

                // Video Media Message
                if (message.messageType == MessageType.VIDEO.name && !message.mediaUrl.isNullOrBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayCircleOutline,
                            contentDescription = "Play video",
                            tint = Color.White,
                            modifier = Modifier.size(54.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                // Document Media Message
                if (message.messageType == MessageType.DOCUMENT.name) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.05f), RoundedCornerShape(6.dp))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Description, contentDescription = "Doc", tint = PakEmeraldGreen, modifier = Modifier.size(32.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(message.fileName ?: "Document", fontWeight = FontWeight.Medium, fontSize = 13.sp, maxLines = 1)
                            Text(
                                text = if ((message.fileSize ?: 0L) > 0) "${(message.fileSize ?: 0L) / 1024} KB" else "PDF Document",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                // Voice Note Message
                if (message.messageType == MessageType.VOICE.name) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onPlayAudio,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(PakEmeraldGreen)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play voice note",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        LinearProgressIndicator(
                            progress = { if (isPlaying) audioProgress else 0f },
                            color = PakEmeraldGreen,
                            modifier = Modifier
                                .weight(1f)
                                .height(4.dp)
                                .clip(CircleShape)
                        )
                    }
                }

                // Text Content
                if (message.messageType != MessageType.VOICE.name || message.text != "🎤 Voice message") {
                    Text(
                        text = message.text,
                        fontSize = 15.sp,
                        color = if (message.deletedForEveryone) Color.Gray else Color(0xFF111B21),
                        fontStyle = if (message.deletedForEveryone) androidx.compose.ui.text.font.FontStyle.Italic else androidx.compose.ui.text.font.FontStyle.Normal
                    )
                }

                // Time & Read Status ticks row
                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (message.isEdited) {
                        Text(
                            text = "Edited ",
                            fontSize = 10.sp,
                            color = Color(0xFF667781)
                        )
                    }

                    if (message.isStarred) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Starred",
                            tint = Color(0xFFFFB300),
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                    }

                    Text(
                        text = TimeUtils.formatMessageTime(message.timestamp),
                        fontSize = 10.sp,
                        color = Color(0xFF667781)
                    )

                    if (isOutgoing) {
                        Spacer(modifier = Modifier.width(4.dp))
                        MessageStatusIcon(status = message.status)
                    }
                }
            }
        }

        // Message Reactions Pill
        if (message.reactions.isNotEmpty()) {
            val emojiString = message.reactions.values.distinct().joinToString(" ")
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 2.dp,
                modifier = Modifier
                    .align(if (isOutgoing) Alignment.BottomEnd else Alignment.BottomStart)
                    .padding(top = 18.dp)
            ) {
                Text(
                    text = emojiString,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}
