package com.pakchat.app.model

data class CallRecord(
    val callId: String = "",
    val callerId: String = "",
    val callerName: String = "",
    val callerPhoto: String = "",
    val receiverId: String = "",
    val receiverName: String = "",
    val receiverPhoto: String = "",
    val callType: String = CallType.VOICE.name,
    val status: String = CallStatus.RINGING.name,
    val timestamp: Long = System.currentTimeMillis(),
    val durationSeconds: Int = 0
)

enum class CallType {
    VOICE,
    VIDEO
}

enum class CallStatus {
    RINGING,
    ACCEPTED,
    REJECTED,
    MISSED,
    ENDED
}
