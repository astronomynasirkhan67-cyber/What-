package com.pakchat.app.model

data class Chat(
    val chatId: String = "",
    val participants: List<String> = emptyList(),
    val participantNames: Map<String, String> = emptyMap(),
    val participantPhotos: Map<String, String> = emptyMap(),
    val participantPhones: Map<String, String> = emptyMap(),
    val lastMessage: String = "",
    val lastMessageTimestamp: Long = System.currentTimeMillis(),
    val lastMessageSenderId: String = "",
    val lastMessageType: String = MessageType.TEXT.name,
    val unreadCounts: Map<String, Int> = emptyMap(),
    val typing: Map<String, Boolean> = emptyMap(),
    val pinnedBy: List<String> = emptyList(),
    val mutedBy: List<String> = emptyList(),
    val isGroup: Boolean = false,
    val groupName: String = "",
    val groupIcon: String = "",
    val groupAdmins: List<String> = emptyList()
) {
    fun getOtherParticipantId(currentUserId: String): String {
        return participants.firstOrNull { it != currentUserId } ?: ""
    }

    fun getDisplayName(currentUserId: String): String {
        return if (isGroup) {
            groupName
        } else {
            val otherId = getOtherParticipantId(currentUserId)
            participantNames[otherId] ?: participantPhones[otherId] ?: "Pak Chat User"
        }
    }

    fun getDisplayPhoto(currentUserId: String): String {
        return if (isGroup) {
            groupIcon
        } else {
            val otherId = getOtherParticipantId(currentUserId)
            participantPhotos[otherId] ?: ""
        }
    }

    fun getUnreadCount(currentUserId: String): Int {
        return unreadCounts[currentUserId] ?: 0
    }

    fun isOtherUserTyping(currentUserId: String): Boolean {
        return typing.any { (uid, isTyping) -> uid != currentUserId && isTyping }
    }

    fun isPinned(currentUserId: String): Boolean {
        return pinnedBy.contains(currentUserId)
    }

    fun isMuted(currentUserId: String): Boolean {
        return mutedBy.contains(currentUserId)
    }
}
