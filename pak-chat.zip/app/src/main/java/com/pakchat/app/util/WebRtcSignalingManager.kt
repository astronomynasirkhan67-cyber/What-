package com.pakchat.app.util

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.util.Log
import com.pakchat.app.data.repository.CallRepository
import com.pakchat.app.model.CallStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * WebRTC Signaling and Media Manager for Pak Chat Voice & Video Calling.
 *
 * Uses Firebase Firestore as the signaling channel for SDP offer/answer
 * and ICE Candidate exchanges between caller and receiver.
 *
 * STUN Servers configured:
 * - stun:stun.l.google.com:19302
 * - stun:stun1.l.google.com:19302
 * - stun:stun2.l.google.com:19302
 *
 * Optional TURN Configuration:
 * For restrictive NAT/symmetric firewalls, a TURN server (e.g. coturn or Twilio TURN)
 * can be specified by adding:
 * IceServer("turn:turn.yourdomain.com:3478", "username", "credential")
 */
class WebRtcSignalingManager(
    private val context: Context,
    private val callRepository: CallRepository = CallRepository()
) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _isSpeakerOn = MutableStateFlow(false)
    val isSpeakerOn: StateFlow<Boolean> = _isSpeakerOn.asStateFlow()

    private val _isVideoEnabled = MutableStateFlow(true)
    val isVideoEnabled: StateFlow<Boolean> = _isVideoEnabled.asStateFlow()

    private val _isFrontCamera = MutableStateFlow(true)
    val isFrontCamera: StateFlow<Boolean> = _isFrontCamera.asStateFlow()

    private val _callState = MutableStateFlow(CallStatus.RINGING)
    val callState: StateFlow<CallStatus> = _callState.asStateFlow()

    fun toggleMute(): Boolean {
        val newMute = !_isMuted.value
        _isMuted.value = newMute
        audioManager.isMicrophoneMute = newMute
        return newMute
    }

    fun toggleSpeaker(): Boolean {
        val newSpeaker = !_isSpeakerOn.value
        _isSpeakerOn.value = newSpeaker
        audioManager.isSpeakerphoneOn = newSpeaker
        return newSpeaker
    }

    fun toggleVideo(): Boolean {
        val newVideo = !_isVideoEnabled.value
        _isVideoEnabled.value = newVideo
        return newVideo
    }

    fun switchCamera(): Boolean {
        val newFront = !_isFrontCamera.value
        _isFrontCamera.value = newFront
        return newFront
    }

    fun release() {
        try {
            audioManager.isMicrophoneMute = false
            audioManager.isSpeakerphoneOn = false
        } catch (e: Exception) {
            Log.e("WebRtcSignaling", "Error releasing audio manager", e)
        }
    }
}
