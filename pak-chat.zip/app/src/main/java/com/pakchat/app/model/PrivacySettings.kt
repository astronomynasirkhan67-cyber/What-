package com.pakchat.app.model

data class PrivacySettings(
    val lastSeenVisibility: String = "Everyone", // Everyone, My Contacts, Nobody
    val onlineStatusVisibility: String = "Everyone", // Everyone, Same as Last Seen
    val profilePhotoVisibility: String = "Everyone", // Everyone, My Contacts, Nobody
    val aboutVisibility: String = "Everyone", // Everyone, My Contacts, Nobody
    val statusVisibility: String = "Everyone", // Everyone, My Contacts, Nobody
    val readReceipts: Boolean = true,
    val blockedUsers: List<String> = emptyList()
)
