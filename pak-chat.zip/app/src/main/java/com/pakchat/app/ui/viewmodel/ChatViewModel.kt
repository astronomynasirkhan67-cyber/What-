package com.pakchat.app.ui.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.pakchat.app.data.repository.ChatRepository
import com.pakchat.app.data.repository.GroupRepository
import com.pakchat.app.data.repository.UserRepository
import com.pakchat.app.model.Group
import com.pakchat.app.model.GroupMember
import com.pakchat.app.model.Message
import com.pakchat.app.model.MessageStatus
import com.pakchat.app.model.MessageType
import com.pakchat.app.model.User
import com.pakchat.app.util.AudioPlayer
import com.pakchat.app.util.VoiceRecorder
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

data class PendingMedia(
    val file: File,
    val type: MessageType,
    val initialCaption: String = "",
    val originalName: String = file.name
)

class ChatViewModel(
    val chatId: String,
    val otherUserId: String,
    private val chatRepository: ChatRepository = ChatRepository(),
    private val groupRepository: GroupRepository = GroupRepository(),
    private val userRepository: UserRepository = UserRepository()
) : ViewModel() {

    val currentUserId: String = FirebaseAuth.getInstance().currentUser?.uid ?: ""
    val isGroup: Boolean = chatId.startsWith("group_")

    private val _otherUser = MutableStateFlow<User?>(null)
    val otherUser: StateFlow<User?> = _otherUser.asStateFlow()

    private val _group = MutableStateFlow<Group?>(null)
    val group: StateFlow<Group?> = _group.asStateFlow()

    private val _groupMembers = MutableStateFlow<List<GroupMember>>(emptyList())
    val groupMembers: StateFlow<List<GroupMember>> = _groupMembers.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _replyingTo = MutableStateFlow<Message?>(null)
    val replyingTo: StateFlow<Message?> = _replyingTo.asStateFlow()

    private val _selectedMessage = MutableStateFlow<Message?>(null)
    val selectedMessage: StateFlow<Message?> = _selectedMessage.asStateFlow()

    private val _selectedMessageIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedMessageIds: StateFlow<Set<String>> = _selectedMessageIds.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _isRecordingVoice = MutableStateFlow(false)
    val isRecordingVoice: StateFlow<Boolean> = _isRecordingVoice.asStateFlow()

    private val _recordingDurationSeconds = MutableStateFlow(0)
    val recordingDurationSeconds: StateFlow<Int> = _recordingDurationSeconds.asStateFlow()

    private val _isUploadingMedia = MutableStateFlow(false)
    val isUploadingMedia: StateFlow<Boolean> = _isUploadingMedia.asStateFlow()

    private val _uploadProgress = MutableStateFlow(0f)
    val uploadProgress: StateFlow<Float> = _uploadProgress.asStateFlow()

    private val _pendingMedia = MutableStateFlow<PendingMedia?>(null)
    val pendingMedia: StateFlow<PendingMedia?> = _pendingMedia.asStateFlow()

    private val _editingMessage = MutableStateFlow<Message?>(null)
    val editingMessage: StateFlow<Message?> = _editingMessage.asStateFlow()

    val audioPlayer = AudioPlayer()
    private var voiceRecorder: VoiceRecorder? = null
    private var recordingTimerJob: Job? = null
    private var typingJob: Job? = null

    val messages: StateFlow<List<Message>> = if (isGroup) {
        groupRepository.getGroupMessagesFlow(chatId)
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    } else {
        chatRepository.getChatMessagesFlow(chatId)
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    }

    init {
        if (isGroup) {
            loadGroupData()
        } else {
            loadOtherUser()
            markAsRead()
        }
    }

    private fun loadOtherUser() {
        if (otherUserId.isNotBlank()) {
            viewModelScope.launch {
                userRepository.getUserFlow(otherUserId).collect { user ->
                    _otherUser.value = user
                }
            }
        }
    }

    private fun loadGroupData() {
        viewModelScope.launch {
            groupRepository.getGroupFlow(chatId).collect { g ->
                _group.value = g
            }
        }
        viewModelScope.launch {
            groupRepository.getGroupMembersFlow(chatId).collect { members ->
                _groupMembers.value = members
            }
        }
    }

    fun markAsRead() {
        if (currentUserId.isNotBlank() && chatId.isNotBlank() && !isGroup) {
            viewModelScope.launch {
                chatRepository.markChatAsRead(chatId, currentUserId)
            }
        }
    }

    fun onInputTextChanged(text: String) {
        _inputText.value = text

        if (!isGroup) {
            typingJob?.cancel()
            typingJob = viewModelScope.launch {
                if (text.isNotBlank()) {
                    chatRepository.setTypingStatus(chatId, currentUserId, true)
                    delay(2500)
                    chatRepository.setTypingStatus(chatId, currentUserId, false)
                } else {
                    chatRepository.setTypingStatus(chatId, currentUserId, false)
                }
            }
        }
    }

    fun setReplyingTo(message: Message?) {
        _replyingTo.value = message
    }

    fun selectMessage(message: Message?) {
        _selectedMessage.value = message
    }

    fun toggleSelectMessage(messageId: String) {
        val current = _selectedMessageIds.value.toMutableSet()
        if (current.contains(messageId)) {
            current.remove(messageId)
        } else {
            current.add(messageId)
        }
        _selectedMessageIds.value = current
    }

    fun clearSelection() {
        _selectedMessageIds.value = emptySet()
        _selectedMessage.value = null
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleSearching() {
        _isSearching.value = !_isSearching.value
        if (!_isSearching.value) {
            _searchQuery.value = ""
        }
    }

    fun setPendingMedia(file: File, type: MessageType, originalName: String = file.name) {
        _pendingMedia.value = PendingMedia(file, type, "", originalName)
    }

    fun clearPendingMedia() {
        _pendingMedia.value = null
    }

    fun setEditingMessage(message: Message?) {
        _editingMessage.value = message
    }

    fun saveEditedMessage(newText: String) {
        val target = _editingMessage.value ?: return
        if (newText.isNotBlank()) {
            viewModelScope.launch {
                chatRepository.editMessage(chatId, target.messageId, newText)
                _editingMessage.value = null
            }
        }
    }

    fun sendTextMessage() {
        val text = _inputText.value.trim()
        if (text.isBlank() || currentUserId.isBlank()) return

        val reply = _replyingTo.value
        val message = Message(
            messageId = UUID.randomUUID().toString(),
            senderId = currentUserId,
            receiverId = otherUserId,
            chatId = chatId,
            text = text,
            messageType = MessageType.TEXT.name,
            timestamp = System.currentTimeMillis(),
            status = MessageStatus.SENT.name,
            replyToId = reply?.messageId,
            replyToText = reply?.text?.take(80),
            replyToSenderName = if (reply?.senderId == currentUserId) "You" else _otherUser.value?.displayName ?: "User"
        )

        _inputText.value = ""
        _replyingTo.value = null

        viewModelScope.launch {
            if (isGroup) {
                groupRepository.sendGroupMessage(chatId, message)
            } else {
                chatRepository.setTypingStatus(chatId, currentUserId, false)
                chatRepository.sendMessage(message)
            }
        }
    }

    fun sendPendingMedia(caption: String) {
        val pending = _pendingMedia.value ?: return
        _pendingMedia.value = null
        when (pending.type) {
            MessageType.IMAGE -> sendImageMessage(pending.file, caption)
            MessageType.VIDEO -> sendVideoMessage(pending.file, caption)
            MessageType.DOCUMENT -> sendDocumentMessage(pending.file, pending.originalName, caption)
            else -> sendImageMessage(pending.file, caption)
        }
    }

    fun sendImageMessage(file: File, caption: String = "") {
        if (currentUserId.isBlank()) return
        _isUploadingMedia.value = true
        _uploadProgress.value = 0.2f

        viewModelScope.launch {
            val uploadResult = if (isGroup) {
                groupRepository.uploadGroupMedia(chatId, file, "jpg")
            } else {
                chatRepository.uploadChatMedia(chatId, file, "jpg")
            }
            _uploadProgress.value = 0.8f

            uploadResult.onSuccess { url ->
                val message = Message(
                    messageId = UUID.randomUUID().toString(),
                    senderId = currentUserId,
                    receiverId = otherUserId,
                    chatId = chatId,
                    text = if (caption.isNotBlank()) caption else "📷 Photo",
                    messageType = MessageType.IMAGE.name,
                    timestamp = System.currentTimeMillis(),
                    status = MessageStatus.SENT.name,
                    mediaUrl = url,
                    fileName = file.name,
                    fileSize = file.length(),
                    uploadStatus = "SUCCESS"
                )
                if (isGroup) {
                    groupRepository.sendGroupMessage(chatId, message)
                } else {
                    chatRepository.sendMessage(message)
                }
            }.onFailure { e ->
                Log.e("ChatViewModel", "Failed to upload image", e)
            }
            _uploadProgress.value = 1f
            _isUploadingMedia.value = false
        }
    }

    fun sendVideoMessage(file: File, caption: String = "") {
        if (currentUserId.isBlank()) return
        _isUploadingMedia.value = true
        _uploadProgress.value = 0.2f

        viewModelScope.launch {
            val uploadResult = if (isGroup) {
                groupRepository.uploadGroupMedia(chatId, file, "mp4")
            } else {
                chatRepository.uploadChatMedia(chatId, file, "mp4")
            }
            _uploadProgress.value = 0.8f

            uploadResult.onSuccess { url ->
                val message = Message(
                    messageId = UUID.randomUUID().toString(),
                    senderId = currentUserId,
                    receiverId = otherUserId,
                    chatId = chatId,
                    text = if (caption.isNotBlank()) caption else "🎥 Video",
                    messageType = MessageType.VIDEO.name,
                    timestamp = System.currentTimeMillis(),
                    status = MessageStatus.SENT.name,
                    mediaUrl = url,
                    fileName = file.name,
                    fileSize = file.length(),
                    uploadStatus = "SUCCESS"
                )
                if (isGroup) {
                    groupRepository.sendGroupMessage(chatId, message)
                } else {
                    chatRepository.sendMessage(message)
                }
            }.onFailure { e ->
                Log.e("ChatViewModel", "Failed to upload video", e)
            }
            _uploadProgress.value = 1f
            _isUploadingMedia.value = false
        }
    }

    fun sendDocumentMessage(file: File, originalName: String, caption: String = "") {
        if (currentUserId.isBlank()) return
        _isUploadingMedia.value = true
        _uploadProgress.value = 0.2f

        val ext = originalName.substringAfterLast('.', "pdf")

        viewModelScope.launch {
            val uploadResult = if (isGroup) {
                groupRepository.uploadGroupMedia(chatId, file, ext)
            } else {
                chatRepository.uploadChatMedia(chatId, file, ext)
            }
            _uploadProgress.value = 0.8f

            uploadResult.onSuccess { url ->
                val message = Message(
                    messageId = UUID.randomUUID().toString(),
                    senderId = currentUserId,
                    receiverId = otherUserId,
                    chatId = chatId,
                    text = if (caption.isNotBlank()) caption else originalName,
                    messageType = MessageType.DOCUMENT.name,
                    timestamp = System.currentTimeMillis(),
                    status = MessageStatus.SENT.name,
                    mediaUrl = url,
                    fileName = originalName,
                    fileSize = file.length(),
                    uploadStatus = "SUCCESS"
                )
                if (isGroup) {
                    groupRepository.sendGroupMessage(chatId, message)
                } else {
                    chatRepository.sendMessage(message)
                }
            }.onFailure { e ->
                Log.e("ChatViewModel", "Failed to upload document", e)
            }
            _uploadProgress.value = 1f
            _isUploadingMedia.value = false
        }
    }

    fun startVoiceRecording(context: Context) {
        voiceRecorder = VoiceRecorder(context)
        val started = voiceRecorder?.startRecording() ?: false
        if (started) {
            _isRecordingVoice.value = true
            _recordingDurationSeconds.value = 0
            recordingTimerJob?.cancel()
            recordingTimerJob = viewModelScope.launch {
                while (_isRecordingVoice.value) {
                    delay(1000)
                    _recordingDurationSeconds.value = voiceRecorder?.getRecordingDurationSeconds() ?: 0
                }
            }
        }
    }

    fun stopAndSendVoiceRecording() {
        recordingTimerJob?.cancel()
        val recordedFile = voiceRecorder?.stopRecording()
        _isRecordingVoice.value = false
        val duration = _recordingDurationSeconds.value
        _recordingDurationSeconds.value = 0

        if (recordedFile != null && recordedFile.exists() && duration >= 1) {
            _isUploadingMedia.value = true
            viewModelScope.launch {
                val uploadResult = if (isGroup) {
                    groupRepository.uploadGroupMedia(chatId, recordedFile, "m4a")
                } else {
                    chatRepository.uploadChatMedia(chatId, recordedFile, "m4a")
                }
                uploadResult.onSuccess { url ->
                    val message = Message(
                        messageId = UUID.randomUUID().toString(),
                        senderId = currentUserId,
                        receiverId = otherUserId,
                        chatId = chatId,
                        text = "🎤 Voice message",
                        messageType = MessageType.VOICE.name,
                        timestamp = System.currentTimeMillis(),
                        status = MessageStatus.SENT.name,
                        mediaUrl = url,
                        fileSize = recordedFile.length(),
                        durationSeconds = duration,
                        uploadStatus = "SUCCESS"
                    )
                    if (isGroup) {
                        groupRepository.sendGroupMessage(chatId, message)
                    } else {
                        chatRepository.sendMessage(message)
                    }
                }.onFailure { e ->
                    Log.e("ChatViewModel", "Failed to upload voice recording", e)
                }
                _isUploadingMedia.value = false
            }
        }
    }

    fun cancelVoiceRecording() {
        recordingTimerJob?.cancel()
        voiceRecorder?.cancelRecording()
        _isRecordingVoice.value = false
        _recordingDurationSeconds.value = 0
    }

    fun addReaction(message: Message, emoji: String) {
        viewModelScope.launch {
            chatRepository.addReaction(chatId, message.messageId, currentUserId, emoji)
            _selectedMessage.value = null
        }
    }

    fun starMessage(message: Message) {
        viewModelScope.launch {
            chatRepository.starMessage(chatId, message.messageId, !message.isStarred)
            _selectedMessage.value = null
        }
    }

    fun deleteForEveryone(message: Message) {
        viewModelScope.launch {
            chatRepository.deleteForEveryone(chatId, message.messageId)
            _selectedMessage.value = null
        }
    }

    fun deleteForMe(message: Message) {
        viewModelScope.launch {
            chatRepository.deleteForMe(chatId, message.messageId, currentUserId)
            _selectedMessage.value = null
        }
    }

    fun deleteSelectedForMe() {
        val ids = _selectedMessageIds.value
        clearSelection()
        viewModelScope.launch {
            for (id in ids) {
                chatRepository.deleteForMe(chatId, id, currentUserId)
            }
        }
    }

    fun forwardMessage(targetChatId: String, targetReceiverId: String, message: Message) {
        viewModelScope.launch {
            chatRepository.forwardMessage(targetChatId, targetReceiverId, currentUserId, message)
            _selectedMessage.value = null
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioPlayer.release()
        cancelVoiceRecording()
        if (currentUserId.isNotBlank() && chatId.isNotBlank() && !isGroup) {
            viewModelScope.launch {
                chatRepository.setTypingStatus(chatId, currentUserId, false)
            }
        }
    }
}
