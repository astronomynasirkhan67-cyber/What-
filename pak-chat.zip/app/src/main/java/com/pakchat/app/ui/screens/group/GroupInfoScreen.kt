package com.pakchat.app.ui.screens.group

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.firebase.auth.FirebaseAuth
import com.pakchat.app.data.repository.GroupRepository
import com.pakchat.app.model.GroupMember
import com.pakchat.app.model.GroupRole
import com.pakchat.app.ui.components.UserAvatar
import com.pakchat.app.ui.theme.PakDarkBackground
import com.pakchat.app.ui.theme.PakEmeraldGreen
import com.pakchat.app.ui.theme.PakGrayText
import com.pakchat.app.ui.theme.PakSurfaceDark
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupInfoScreen(
    groupId: String,
    onNavigateBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val groupRepository = remember { GroupRepository() }
    val currentUserId = FirebaseAuth.getInstance().currentUser?.uid ?: ""

    val group by groupRepository.getGroupFlow(groupId).collectAsState(initial = null)
    val members by groupRepository.getGroupMembersFlow(groupId).collectAsState(initial = emptyList())

    val isCurrentUserAdmin = group?.isAdmin(currentUserId) == true

    var showEditInfoDialog by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf("") }
    var editDesc by remember { mutableStateOf("") }
    var editOnlyAdmins by remember { mutableStateOf(false) }

    var selectedMemberForMenu by remember { mutableStateOf<GroupMember?>(null) }
    var showLeaveConfirmDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Group Info", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PakSurfaceDark)
            )
        },
        containerColor = PakDarkBackground
    ) { paddingValues ->
        val currentGroup = group

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Header: Icon, Name, Members count
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PakSurfaceDark)
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (!currentGroup?.iconUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = currentGroup?.iconUrl,
                            contentDescription = "Group Icon",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(96.dp)
                                .clip(CircleShape)
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(96.dp)
                                .clip(CircleShape)
                                .background(PakEmeraldGreen.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Group,
                                contentDescription = null,
                                tint = PakEmeraldGreen,
                                modifier = Modifier.size(48.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = currentGroup?.name ?: "Group",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Group · ${members.size} participants",
                        fontSize = 14.sp,
                        color = PakGrayText
                    )

                    if (!currentGroup?.description.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = currentGroup?.description ?: "",
                            fontSize = 14.sp,
                            color = Color.LightGray
                        )
                    }
                }
            }

            // Group Settings Card (For Admins)
            if (isCurrentUserAdmin) {
                item {
                    Spacer(modifier = Modifier.height(12.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(PakSurfaceDark)
                            .padding(16.dp)
                    ) {
                        Text("Group Permissions", color = PakEmeraldGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Only admins can send messages", color = Color.White, fontSize = 15.sp)
                                Text("Other members will only be able to read", color = PakGrayText, fontSize = 12.sp)
                            }
                            Switch(
                                checked = currentGroup?.onlyAdminsCanMessage == true,
                                onCheckedChange = { checked ->
                                    coroutineScope.launch {
                                        groupRepository.updateGroupSettings(
                                            groupId = groupId,
                                            name = currentGroup?.name ?: "",
                                            description = currentGroup?.description ?: "",
                                            onlyAdminsCanMessage = checked
                                        )
                                    }
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = PakEmeraldGreen
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        TextButton(
                            onClick = {
                                editName = currentGroup?.name ?: ""
                                editDesc = currentGroup?.description ?: ""
                                editOnlyAdmins = currentGroup?.onlyAdminsCanMessage == true
                                showEditInfoDialog = true
                            }
                        ) {
                            Text("Edit Group Name & Description", color = PakEmeraldGreen)
                        }
                    }
                }
            }

            // Participants Header
            item {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PakSurfaceDark)
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${members.size} participants",
                        color = PakEmeraldGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            // Members List
            items(members) { member ->
                val isMemberAdmin = member.role == GroupRole.ADMIN.name
                val isSelf = member.uid == currentUserId

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PakSurfaceDark)
                        .clickable(enabled = isCurrentUserAdmin && !isSelf) {
                            selectedMemberForMenu = member
                        }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(photoUrl = member.photoUrl, displayName = member.displayName, size = 44.dp)

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isSelf) "You" else member.displayName,
                            color = Color.White,
                            fontWeight = FontWeight.Medium,
                            fontSize = 16.sp
                        )
                        Text(
                            text = member.phoneNumber,
                            color = PakGrayText,
                            fontSize = 13.sp
                        )
                    }

                    if (isMemberAdmin) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(PakEmeraldGreen.copy(alpha = 0.2f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Group Admin",
                                color = PakEmeraldGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (isCurrentUserAdmin && !isSelf) {
                        IconButton(onClick = { selectedMemberForMenu = member }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Options", tint = PakGrayText)
                        }
                    }
                }

                HorizontalDivider(color = Color.DarkGray.copy(alpha = 0.3f), thickness = 0.5.dp)
            }

            // Leave Group Item
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PakSurfaceDark)
                        .clickable { showLeaveConfirmDialog = true }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Exit Group", tint = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("Exit group", color = MaterialTheme.colorScheme.error, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }

        // Member action dropdown / dialog
        val targetMember = selectedMemberForMenu
        if (targetMember != null && isCurrentUserAdmin) {
            val isTargetAdmin = targetMember.role == GroupRole.ADMIN.name
            AlertDialog(
                onDismissRequest = { selectedMemberForMenu = null },
                title = { Text(targetMember.displayName, color = Color.White) },
                text = {
                    Column {
                        TextButton(
                            onClick = {
                                coroutineScope.launch {
                                    groupRepository.setAdminRole(groupId, targetMember.uid, !isTargetAdmin)
                                    selectedMemberForMenu = null
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isTargetAdmin) "Dismiss as admin" else "Make group admin", color = PakEmeraldGreen)
                        }

                        TextButton(
                            onClick = {
                                coroutineScope.launch {
                                    groupRepository.removeMember(groupId, targetMember.uid)
                                    selectedMemberForMenu = null
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Remove from group", color = MaterialTheme.colorScheme.error)
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { selectedMemberForMenu = null }) {
                        Text("Cancel", color = Color.White)
                    }
                },
                containerColor = PakSurfaceDark
            )
        }

        // Leave Confirm Dialog
        if (showLeaveConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showLeaveConfirmDialog = false },
                title = { Text("Exit \"${currentGroup?.name}\" group?", color = Color.White) },
                text = { Text("You will no longer receive messages from this group.", color = PakGrayText) },
                confirmButton = {
                    TextButton(
                        onClick = {
                            coroutineScope.launch {
                                groupRepository.removeMember(groupId, currentUserId)
                                showLeaveConfirmDialog = false
                                onNavigateBack()
                            }
                        }
                    ) {
                        Text("Exit", color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showLeaveConfirmDialog = false }) {
                        Text("Cancel", color = Color.White)
                    }
                },
                containerColor = PakSurfaceDark
            )
        }

        // Edit Group Info Dialog
        if (showEditInfoDialog) {
            AlertDialog(
                onDismissRequest = { showEditInfoDialog = false },
                title = { Text("Edit Group Info", color = Color.White) },
                text = {
                    Column {
                        OutlinedTextField(
                            value = editName,
                            onValueChange = { editName = it },
                            label = { Text("Group Subject", color = PakGrayText) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = PakEmeraldGreen,
                                unfocusedBorderColor = Color.Gray
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = editDesc,
                            onValueChange = { editDesc = it },
                            label = { Text("Description", color = PakGrayText) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = PakEmeraldGreen,
                                unfocusedBorderColor = Color.Gray
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            if (editName.isNotBlank()) {
                                coroutineScope.launch {
                                    groupRepository.updateGroupSettings(
                                        groupId = groupId,
                                        name = editName.trim(),
                                        description = editDesc.trim(),
                                        onlyAdminsCanMessage = editOnlyAdmins
                                    )
                                    showEditInfoDialog = false
                                }
                            }
                        }
                    ) {
                        Text("Save", color = PakEmeraldGreen)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showEditInfoDialog = false }) {
                        Text("Cancel", color = Color.White)
                    }
                },
                containerColor = PakSurfaceDark
            )
        }
    }
}
