package com.pakchat.app.model

data class Message(
    val messageId: String = "",
    val senderId: String = "",
    val receiverId: String = "",
    val chatId: String = "",
    val text: String = "",
    val messageType: String = MessageType.TEXT.name,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = MessageStatus.SENT.name,
    val replyToId: String? = null,
    val replyToText: String? = null,
    val replyToSenderName: String? = null,
    val mediaUrl: String? = null,
    val fileName: String? = null,
    val fileSize: Long? = null,
    val reactions: Map<String, String> = emptyMap(),
    val isStarred: Boolean = false,
    val isEdited: Boolean = false,
    val uploadStatus: String = "SUCCESS", // "SUCCESS", "UPLOADING", "FAILED"
    val durationSeconds: Int = 0,
    val deletedForEveryone: Boolean = false,
    val deletedForUsers: List<String> = emptyList()
)

enum class MessageType {
    TEXT,
    IMAGE,
    VIDEO,
    AUDIO,
    DOCUMENT,
    VOICE,
    LOCATION,
    SYSTEM
}

enum class MessageStatus {
    SENT,
    DELIVERED,
    READ
}
