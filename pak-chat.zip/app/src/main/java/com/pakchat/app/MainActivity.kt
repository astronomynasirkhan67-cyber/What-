package com.pakchat.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pakchat.app.data.repository.AuthRepository
import com.pakchat.app.ui.screens.auth.OtpVerifyScreen
import com.pakchat.app.ui.screens.auth.PhoneAuthScreen
import com.pakchat.app.ui.screens.auth.ProfileSetupScreen
import com.pakchat.app.ui.screens.call.CallScreen
import com.pakchat.app.ui.screens.chat.ChatScreen
import com.pakchat.app.ui.screens.group.CreateGroupScreen
import com.pakchat.app.ui.screens.group.GroupInfoScreen
import com.pakchat.app.ui.screens.home.HomeScreen
import com.pakchat.app.ui.screens.newchat.NewChatScreen
import com.pakchat.app.ui.screens.profile.ProfileScreen
import com.pakchat.app.ui.screens.settings.PrivacySettingsScreen
import com.pakchat.app.ui.screens.settings.SettingsScreen
import com.pakchat.app.ui.screens.status.CreateStatusScreen
import com.pakchat.app.ui.screens.status.StatusViewerScreen
import com.pakchat.app.ui.theme.PakChatTheme
import com.pakchat.app.ui.viewmodel.AuthViewModel
import com.pakchat.app.ui.viewmodel.ChatViewModel
import com.pakchat.app.ui.viewmodel.HomeViewModel

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Request runtime permissions on start
        requestRequiredPermissions()

        val incomingChatId = intent.getStringExtra("chatId")
        val incomingSenderId = intent.getStringExtra("senderId")

        setContent {
            PakChatTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    PakChatNavigation(
                        initialChatId = incomingChatId,
                        initialSenderId = incomingSenderId
                    )
                }
            }
        }
    }

    private fun requestRequiredPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val ungranted = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (ungranted.isNotEmpty()) {
            requestPermissionLauncher.launch(ungranted.toTypedArray())
        }
    }
}

@Composable
fun PakChatNavigation(
    initialChatId: String? = null,
    initialSenderId: String? = null
) {
    val navController = rememberNavController()
    val authRepository = AuthRepository()
    val isUserLoggedIn = authRepository.isUserLoggedIn()

    val startDestination = if (isUserLoggedIn) "home" else "phone_auth"

    val authViewModel: AuthViewModel = viewModel()
    val homeViewModel: HomeViewModel = viewModel()

    // Handle deep link notification navigation
    LaunchedEffect(initialChatId, initialSenderId) {
        if (!initialChatId.isNullOrBlank() && !initialSenderId.isNullOrBlank() && isUserLoggedIn) {
            navController.navigate("chat/$initialChatId/$initialSenderId")
        }
    }

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable("phone_auth") {
            PhoneAuthScreen(
                viewModel = authViewModel,
                onNavigateToOtp = { navController.navigate("otp_verify") },
                onNavigateToHome = {
                    navController.navigate("home") {
                        popUpTo("phone_auth") { inclusive = true }
                    }
                },
                onNavigateToProfileSetup = {
                    navController.navigate("profile_setup") {
                        popUpTo("phone_auth") { inclusive = true }
                    }
                }
            )
        }

        composable("otp_verify") {
            OtpVerifyScreen(
                viewModel = authViewModel,
                onNavigateToHome = {
                    navController.navigate("home") {
                        popUpTo("phone_auth") { inclusive = true }
                    }
                },
                onNavigateToProfileSetup = {
                    navController.navigate("profile_setup") {
                        popUpTo("phone_auth") { inclusive = true }
                    }
                },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("profile_setup") {
            ProfileSetupScreen(
                viewModel = authViewModel,
                onProfileCompleted = {
                    navController.navigate("home") {
                        popUpTo("profile_setup") { inclusive = true }
                    }
                }
            )
        }

        composable("home") {
            HomeScreen(
                viewModel = homeViewModel,
                onNavigateToChat = { chatId, otherUserId ->
                    navController.navigate("chat/$chatId/$otherUserId")
                },
                onNavigateToNewChat = { navController.navigate("new_chat") },
                onNavigateToCreateGroup = { navController.navigate("create_group") },
                onNavigateToProfile = { navController.navigate("profile") },
                onNavigateToSettings = { navController.navigate("settings") },
                onNavigateToCreateStatus = { navController.navigate("create_status") },
                onNavigateToStatusViewer = { statusId ->
                    navController.navigate("status_viewer/$statusId")
                },
                onSignOut = {
                    authViewModel.signOut()
                    navController.navigate("phone_auth") {
                        popUpTo("home") { inclusive = true }
                    }
                }
            )
        }

        composable("create_group") {
            CreateGroupScreen(
                onNavigateBack = { navController.popBackStack() },
                onGroupCreated = { groupId ->
                    navController.navigate("chat/$groupId/group") {
                        popUpTo("create_group") { inclusive = true }
                    }
                }
            )
        }

        composable(
            route = "group_info/{groupId}",
            arguments = listOf(navArgument("groupId") { type = NavType.StringType })
        ) { backStackEntry ->
            val groupId = backStackEntry.arguments?.getString("groupId") ?: ""
            GroupInfoScreen(
                groupId = groupId,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = "chat/{chatId}/{otherUserId}",
            arguments = listOf(
                navArgument("chatId") { type = NavType.StringType },
                navArgument("otherUserId") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val chatId = backStackEntry.arguments?.getString("chatId") ?: ""
            val otherUserId = backStackEntry.arguments?.getString("otherUserId") ?: ""

            val chatViewModel = viewModel<ChatViewModel>(
                key = "chat_$chatId",
                factory = object : androidx.lifecycle.ViewModelProvider.Factory {
                    @Suppress("UNCHECKED_CAST")
                    override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T {
                        return ChatViewModel(chatId = chatId, otherUserId = otherUserId) as T
                    }
                }
            )

            ChatScreen(
                viewModel = chatViewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToCall = { userId, isVideo ->
                    navController.navigate("call/$userId?isVideo=$isVideo")
                },
                onNavigateToGroupInfo = { grpId ->
                    navController.navigate("group_info/$grpId")
                }
            )
        }

        composable("new_chat") {
            NewChatScreen(
                viewModel = homeViewModel,
                onNavigateBack = { navController.popBackStack() },
                onUserSelected = { chatId, otherUserId ->
                    navController.navigate("chat/$chatId/$otherUserId") {
                        popUpTo("new_chat") { inclusive = true }
                    }
                }
            )
        }

        composable("profile") {
            ProfileScreen(
                viewModel = homeViewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("settings") {
            SettingsScreen(
                viewModel = homeViewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToProfile = { navController.navigate("profile") },
                onNavigateToPrivacy = { navController.navigate("privacy_settings") },
                onSignOut = {
                    authViewModel.signOut()
                    navController.navigate("phone_auth") {
                        popUpTo("home") { inclusive = true }
                    }
                }
            )
        }

        composable("privacy_settings") {
            PrivacySettingsScreen(
                onNavigateBack = { navController.popBackStack() },
                onAccountDeleted = {
                    authViewModel.signOut()
                    navController.navigate("phone_auth") {
                        popUpTo("home") { inclusive = true }
                    }
                }
            )
        }

        composable("create_status") {
            CreateStatusScreen(
                viewModel = homeViewModel,
                onStatusPosted = { navController.popBackStack() },
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = "status_viewer/{statusId}",
            arguments = listOf(navArgument("statusId") { type = NavType.StringType })
        ) { backStackEntry ->
            val statusId = backStackEntry.arguments?.getString("statusId") ?: ""
            StatusViewerScreen(
                statusId = statusId,
                viewModel = homeViewModel,
                onClose = { navController.popBackStack() }
            )
        }

        composable(
            route = "call/{otherUserId}?isVideo={isVideo}",
            arguments = listOf(
                navArgument("otherUserId") { type = NavType.StringType },
                navArgument("isVideo") {
                    type = NavType.BoolType
                    defaultValue = false
                }
            )
        ) { backStackEntry ->
            val otherUserId = backStackEntry.arguments?.getString("otherUserId") ?: ""
            val isVideo = backStackEntry.arguments?.getBoolean("isVideo") ?: false

            CallScreen(
                otherUserId = otherUserId,
                isVideo = isVideo,
                currentUserId = homeViewModel.currentUserId,
                onCallEnded = { navController.popBackStack() }
            )
        }
    }
}
