package com.pakchat.app.data.repository

import android.net.Uri
import android.util.Log
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.pakchat.app.model.StatusItem
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.io.File
import java.util.UUID

class StatusRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val storage: FirebaseStorage = FirebaseStorage.getInstance()
) {

    private val statusesCollection = firestore.collection("statuses")

    suspend fun postStatus(statusItem: StatusItem): Result<Unit> {
        return try {
            val statusId = if (statusItem.statusId.isBlank()) UUID.randomUUID().toString() else statusItem.statusId
            val finalStatus = statusItem.copy(statusId = statusId)
            statusesCollection.document(statusId).set(finalStatus).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("StatusRepository", "Failed to post status", e)
            Result.failure(e)
        }
    }

    fun getAllActiveStatusesFlow(): Flow<List<StatusItem>> = callbackFlow {
        val twentyFourHoursAgo = System.currentTimeMillis() - 24 * 60 * 60 * 1000L
        val listener = statusesCollection
            .whereGreaterThan("timestamp", twentyFourHoursAgo)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("StatusRepository", "Error fetching statuses", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }

                val statuses = snapshot?.documents?.mapNotNull { it.toObject(StatusItem::class.java) }
                    ?.sortedByDescending { it.timestamp }
                    ?: emptyList()

                trySend(statuses)
            }

        awaitClose { listener.remove() }
    }

    suspend fun markStatusViewed(statusId: String, currentUserId: String) {
        try {
            statusesCollection.document(statusId)
                .update("viewedBy", FieldValue.arrayUnion(currentUserId))
                .await()
        } catch (e: Exception) {
            Log.e("StatusRepository", "Failed to mark status viewed", e)
        }
    }

    suspend fun uploadStatusMedia(file: File): Result<String> {
        return try {
            val fileName = "status_${UUID.randomUUID()}.jpg"
            val ref = storage.reference.child("statuses/$fileName")
            ref.putFile(Uri.fromFile(file)).await()
            val downloadUrl = ref.downloadUrl.await().toString()
            Result.success(downloadUrl)
        } catch (e: Exception) {
            Log.e("StatusRepository", "Failed to upload status media", e)
            Result.failure(e)
        }
    }
}
