package com.pakchat.app.ui.viewmodel

import android.app.Activity
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider
import com.pakchat.app.data.repository.AuthRepository
import com.pakchat.app.data.repository.UserRepository
import com.pakchat.app.model.User
import com.pakchat.app.util.PhoneNumberValidator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

sealed interface AuthUiState {
    data object Idle : AuthUiState
    data object SendingOtp : AuthUiState
    data class OtpSent(val verificationId: String) : AuthUiState
    data object VerifyingOtp : AuthUiState
    data class Authenticated(val user: FirebaseUser, val isProfileComplete: Boolean) : AuthUiState
    data class Error(val message: String) : AuthUiState
}

class AuthViewModel(
    private val authRepository: AuthRepository = AuthRepository(),
    private val userRepository: UserRepository = UserRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private val _phoneNumber = MutableStateFlow("")
    val phoneNumber: StateFlow<String> = _phoneNumber.asStateFlow()

    private val _otpCode = MutableStateFlow("")
    val otpCode: StateFlow<String> = _otpCode.asStateFlow()

    private val _displayName = MutableStateFlow("")
    val displayName: StateFlow<String> = _displayName.asStateFlow()

    private val _about = MutableStateFlow("Hey there! I am using Pak Chat.")
    val about: StateFlow<String> = _about.asStateFlow()

    private val _selectedPhotoFile = MutableStateFlow<File?>(null)
    val selectedPhotoFile: StateFlow<File?> = _selectedPhotoFile.asStateFlow()

    private var verificationId: String? = null
    private var resendToken: PhoneAuthProvider.ForceResendingToken? = null

    init {
        checkCurrentAuthStatus()
    }

    private fun checkCurrentAuthStatus() {
        val user = authRepository.currentUser
        if (user != null) {
            viewModelScope.launch {
                val userDoc = userRepository.getUserOnce(user.uid)
                val isProfileComplete = userDoc != null && userDoc.displayName.isNotBlank()
                _uiState.value = AuthUiState.Authenticated(user, isProfileComplete)
            }
        }
    }

    fun setPhoneNumber(input: String) {
        _phoneNumber.value = input
    }

    fun setOtpCode(code: String) {
        _otpCode.value = code
    }

    fun setDisplayName(name: String) {
        _displayName.value = name
    }

    fun setAbout(text: String) {
        _about.value = text
    }

    fun setPhotoFile(file: File?) {
        _selectedPhotoFile.value = file
    }

    fun sendOtp(activity: Activity) {
        val rawNumber = _phoneNumber.value.trim()
        val normalizedNumber = PhoneNumberValidator.normalizePakistaniNumber(rawNumber)

        if (!PhoneNumberValidator.isValidPakistaniNumber(normalizedNumber)) {
            _uiState.value = AuthUiState.Error("Please enter a valid Pakistani mobile number (e.g., 0300 1234567)")
            return
        }

        _uiState.value = AuthUiState.SendingOtp

        authRepository.sendOtp(
            phoneNumber = normalizedNumber,
            activity = activity,
            callback = object : AuthRepository.OtpCallback {
                override fun onCodeSent(
                    vId: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    verificationId = vId
                    resendToken = token
                    _uiState.value = AuthUiState.OtpSent(vId)
                }

                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    viewModelScope.launch {
                        _uiState.value = AuthUiState.VerifyingOtp
                        val result = authRepository.signInWithCredential(credential)
                        result.onSuccess { user ->
                            handleSuccessfulAuth(user, normalizedNumber)
                        }.onFailure { e ->
                            _uiState.value = AuthUiState.Error(e.localizedMessage ?: "Auto-verification failed")
                        }
                    }
                }

                override fun onVerificationFailed(exception: FirebaseException) {
                    _uiState.value = AuthUiState.Error(
                        exception.localizedMessage ?: "Phone verification failed. Ensure internet connection."
                    )
                }
            },
            resendToken = resendToken
        )
    }

    fun verifyOtp() {
        val vId = verificationId
        val code = _otpCode.value.trim()

        if (vId == null || code.length < 6) {
            _uiState.value = AuthUiState.Error("Please enter the complete 6-digit OTP code")
            return
        }

        _uiState.value = AuthUiState.VerifyingOtp

        viewModelScope.launch {
            val result = authRepository.verifyOtpCode(vId, code)
            result.onSuccess { user ->
                val normalizedNumber = PhoneNumberValidator.normalizePakistaniNumber(_phoneNumber.value)
                handleSuccessfulAuth(user, normalizedNumber)
            }.onFailure { e ->
                _uiState.value = AuthUiState.Error(e.localizedMessage ?: "Invalid OTP code. Please try again.")
            }
        }
    }

    /**
     * Test / Quick dev sign-in helper so two test phones/emulators can instantly test real-time chat
     * without blocking on telecom carrier SMS quotas.
     */
    fun devQuickSignIn(phoneInput: String, defaultName: String) {
        val normalized = PhoneNumberValidator.normalizePakistaniNumber(phoneInput)
        _uiState.value = AuthUiState.VerifyingOtp

        viewModelScope.launch {
            val result = authRepository.devSignInWithCustomId(normalized)
            result.onSuccess { user ->
                val existing = userRepository.getUserOnce(user.uid)
                if (existing == null || existing.displayName.isBlank()) {
                    val newUser = User(
                        uid = user.uid,
                        phoneNumber = normalized,
                        displayName = defaultName,
                        about = "Hey there! I am using Pak Chat.",
                        createdAt = System.currentTimeMillis(),
                        isOnline = true
                    )
                    userRepository.saveUser(newUser)
                }
                _uiState.value = AuthUiState.Authenticated(user, isProfileComplete = true)
            }.onFailure { e ->
                _uiState.value = AuthUiState.Error("Quick login failed: ${e.localizedMessage}")
            }
        }
    }

    private suspend fun handleSuccessfulAuth(user: FirebaseUser, phoneNumber: String) {
        val existingUser = userRepository.getUserOnce(user.uid)
        if (existingUser != null && existingUser.displayName.isNotBlank()) {
            userRepository.updatePresence(user.uid, true)
            _uiState.value = AuthUiState.Authenticated(user, isProfileComplete = true)
        } else {
            // New user, create initial record and prompt profile completion
            val initialUser = User(
                uid = user.uid,
                phoneNumber = phoneNumber,
                displayName = "",
                about = "Hey there! I am using Pak Chat.",
                createdAt = System.currentTimeMillis(),
                isOnline = true
            )
            userRepository.saveUser(initialUser)
            _uiState.value = AuthUiState.Authenticated(user, isProfileComplete = false)
        }
    }

    fun completeProfile(onSuccess: () -> Unit) {
        val user = authRepository.currentUser ?: return
        val name = _displayName.value.trim()
        val aboutText = _about.value.trim().ifEmpty { "Hey there! I am using Pak Chat." }

        if (name.isBlank()) {
            _uiState.value = AuthUiState.Error("Please enter your display name")
            return
        }

        viewModelScope.launch {
            var photoUrl = ""
            val photoFile = _selectedPhotoFile.value
            if (photoFile != null) {
                val uploadResult = userRepository.uploadProfilePhoto(user.uid, photoFile)
                photoUrl = uploadResult.getOrDefault("")
            }

            val phone = user.phoneNumber ?: PhoneNumberValidator.normalizePakistaniNumber(_phoneNumber.value)
            val updatedUser = User(
                uid = user.uid,
                phoneNumber = phone,
                displayName = name,
                photoUrl = photoUrl,
                about = aboutText,
                createdAt = System.currentTimeMillis(),
                lastSeen = System.currentTimeMillis(),
                isOnline = true
            )

            val saveResult = userRepository.saveUser(updatedUser)
            saveResult.onSuccess {
                _uiState.value = AuthUiState.Authenticated(user, isProfileComplete = true)
                onSuccess()
            }.onFailure { e ->
                _uiState.value = AuthUiState.Error("Failed to save profile: ${e.localizedMessage}")
            }
        }
    }

    fun resetState() {
        _uiState.value = AuthUiState.Idle
    }

    fun signOut() {
        val uid = authRepository.currentUserId
        if (uid != null) {
            viewModelScope.launch {
                userRepository.updatePresence(uid, false)
                authRepository.signOut()
                _uiState.value = AuthUiState.Idle
            }
        } else {
            authRepository.signOut()
            _uiState.value = AuthUiState.Idle
        }
    }
}
