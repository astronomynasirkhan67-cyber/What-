package com.pakchat.app.ui.screens.call

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pakchat.app.data.repository.CallRepository
import com.pakchat.app.data.repository.UserRepository
import com.pakchat.app.model.CallRecord
import com.pakchat.app.model.CallStatus
import com.pakchat.app.model.CallType
import com.pakchat.app.model.User
import com.pakchat.app.ui.components.UserAvatar
import com.pakchat.app.ui.theme.PakDarkBackground
import com.pakchat.app.util.TimeUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun CallScreen(
    otherUserId: String,
    isVideo: Boolean,
    currentUserId: String,
    onCallEnded: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val userRepository = remember { UserRepository() }
    val callRepository = remember { CallRepository() }

    var otherUser by remember { mutableStateOf<User?>(null) }
    var currentUser by remember { mutableStateOf<User?>(null) }
    var callId by remember { mutableStateOf("") }
    var callStatus by remember { mutableStateOf(CallStatus.RINGING) }
    var durationSeconds by remember { mutableIntStateOf(0) }

    var isMuted by remember { mutableStateOf(false) }
    var isSpeakerOn by remember { mutableStateOf(false) }
    var isVideoMuted by remember { mutableStateOf(false) }

    LaunchedEffect(otherUserId) {
        otherUser = userRepository.getUserOnce(otherUserId)
        currentUser = userRepository.getUserOnce(currentUserId)

        val target = otherUser
        val me = currentUser
        if (target != null && me != null) {
            val record = CallRecord(
                callerId = currentUserId,
                callerName = me.displayName,
                callerPhoto = me.photoUrl,
                receiverId = otherUserId,
                receiverName = target.displayName,
                receiverPhoto = target.photoUrl,
                callType = if (isVideo) CallType.VIDEO.name else CallType.VOICE.name,
                status = CallStatus.RINGING.name
            )
            val result = callRepository.initiateCall(record)
            callId = result.getOrDefault("")
        }

        // Simulate pickup after 2.5s for seamless interactive experience
        delay(2500)
        callStatus = CallStatus.ACCEPTED
        if (callId.isNotBlank()) {
            callRepository.updateCallStatus(callId, CallStatus.ACCEPTED)
        }

        while (true) {
            delay(1000)
            durationSeconds++
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(PakDarkBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(48.dp))

            Text(
                text = otherUser?.displayName ?: "Pak Chat User",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(8.dp))

            val statusText = when (callStatus) {
                CallStatus.RINGING -> "Ringing..."
                CallStatus.ACCEPTED -> TimeUtils.formatDuration(durationSeconds)
                else -> "Call ended"
            }

            Text(
                text = statusText,
                fontSize = 16.sp,
                color = Color.White.copy(alpha = 0.7f)
            )

            Spacer(modifier = Modifier.height(60.dp))

            UserAvatar(
                photoUrl = otherUser?.photoUrl,
                name = otherUser?.displayName ?: "User",
                size = 140.dp
            )

            Spacer(modifier = Modifier.weight(1f))

            // Control buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 32.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { isMuted = !isMuted },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(if (isMuted) Color.White else Color.White.copy(alpha = 0.2f))
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute",
                        tint = if (isMuted) Color.Black else Color.White
                    )
                }

                if (isVideo) {
                    IconButton(
                        onClick = { isVideoMuted = !isVideoMuted },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(if (isVideoMuted) Color.White else Color.White.copy(alpha = 0.2f))
                    ) {
                        Icon(
                            imageVector = if (isVideoMuted) Icons.Default.VideocamOff else Icons.Default.Videocam,
                            contentDescription = "Camera",
                            tint = if (isVideoMuted) Color.Black else Color.White
                        )
                    }
                } else {
                    IconButton(
                        onClick = { isSpeakerOn = !isSpeakerOn },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(if (isSpeakerOn) Color.White else Color.White.copy(alpha = 0.2f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Speaker",
                            tint = if (isSpeakerOn) Color.Black else Color.White
                        )
                    }
                }

                // End call button (red)
                FloatingActionButton(
                    onClick = {
                        if (callId.isNotBlank()) {
                            coroutineScope.launch {
                                callRepository.updateCallStatus(callId, CallStatus.ENDED, durationSeconds)
                            }
                        }
                        onCallEnded()
                    },
                    containerColor = MaterialTheme.colorScheme.error,
                    contentColor = Color.White,
                    shape = CircleShape,
                    modifier = Modifier.size(64.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "End Call",
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}
