package com.pakchat.app.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pakchat.app.model.CallRecord
import com.pakchat.app.model.CallStatus
import com.pakchat.app.model.CallType
import com.pakchat.app.model.Chat
import com.pakchat.app.model.StatusItem
import com.pakchat.app.ui.components.MessageStatusIcon
import com.pakchat.app.ui.components.UserAvatar
import com.pakchat.app.ui.theme.PakEmeraldGreen
import com.pakchat.app.ui.theme.PakLightTeal
import com.pakchat.app.ui.viewmodel.HomeViewModel
import com.pakchat.app.util.TimeUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onNavigateToChat: (chatId: String, otherUserId: String) -> Unit,
    onNavigateToNewChat: () -> Unit,
    onNavigateToCreateGroup: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToCreateStatus: () -> Unit,
    onNavigateToStatusViewer: (statusId: String) -> Unit,
    onSignOut: () -> Unit
) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val isSearchActive by viewModel.isSearchActive.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val filteredChats by viewModel.filteredChats.collectAsState()
    val activeStatuses by viewModel.activeStatuses.collectAsState()
    val callHistory by viewModel.callHistory.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()

    var showMenu by remember { mutableStateOf(false) }

    val totalUnreadCount = filteredChats.sumOf { it.getUnreadCount(viewModel.currentUserId) }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        if (isSearchActive) {
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { viewModel.setSearchQuery(it) },
                                placeholder = { Text("Search chats or messages...", color = Color.White.copy(alpha = 0.7f)) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White,
                                    cursorColor = Color.White,
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        } else {
                            Text(
                                text = "Pak Chat",
                                fontWeight = FontWeight.Bold,
                                fontSize = 21.sp,
                                color = Color.White
                            )
                        }
                    },
                    actions = {
                        if (isSearchActive) {
                            IconButton(onClick = { viewModel.toggleSearch() }) {
                                Icon(Icons.Default.Close, contentDescription = "Close search", tint = Color.White)
                            }
                        } else {
                            IconButton(onClick = { viewModel.toggleSearch() }) {
                                Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.White)
                            }
                            IconButton(onClick = onNavigateToCreateStatus) {
                                Icon(Icons.Default.CameraAlt, contentDescription = "Camera", tint = Color.White)
                            }
                            IconButton(onClick = { showMenu = !showMenu }) {
                                Icon(Icons.Default.MoreVert, contentDescription = "More", tint = Color.White)
                            }

                            DropdownMenu(
                                expanded = showMenu,
                                onDismissRequest = { showMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("New group") },
                                    onClick = {
                                        showMenu = false
                                        onNavigateToCreateGroup()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("New chat") },
                                    onClick = {
                                        showMenu = false
                                        onNavigateToNewChat()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("My Profile") },
                                    onClick = {
                                        showMenu = false
                                        onNavigateToProfile()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Settings") },
                                    onClick = {
                                        showMenu = false
                                        onNavigateToSettings()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Log out", color = MaterialTheme.colorScheme.error) },
                                    onClick = {
                                        showMenu = false
                                        onSignOut()
                                    }
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = PakEmeraldGreen)
                )

                // Tabs (CHATS, STATUS, CALLS)
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = PakEmeraldGreen,
                    contentColor = Color.White,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            height = 3.dp,
                            color = Color.White
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { viewModel.setSelectedTab(0) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "CHATS",
                                    fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Medium
                                )
                                if (totalUnreadCount > 0) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Badge(
                                        containerColor = Color.White,
                                        contentColor = PakEmeraldGreen
                                    ) {
                                        Text(text = "$totalUnreadCount", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { viewModel.setSelectedTab(1) },
                        text = {
                            Text(
                                text = "STATUS",
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { viewModel.setSelectedTab(2) },
                        text = {
                            Text(
                                text = "CALLS",
                                fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                }
            }
        },
        floatingActionButton = {
            when (selectedTab) {
                0 -> {
                    FloatingActionButton(
                        onClick = onNavigateToNewChat,
                        containerColor = PakLightTeal,
                        contentColor = Color.White,
                        shape = CircleShape
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = "New Chat")
                    }
                }
                1 -> {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        FloatingActionButton(
                            onClick = onNavigateToCreateStatus,
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            shape = CircleShape,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Text Status", modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        FloatingActionButton(
                            onClick = onNavigateToCreateStatus,
                            containerColor = PakLightTeal,
                            contentColor = Color.White,
                            shape = CircleShape
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Photo Status")
                        }
                    }
                }
                2 -> {
                    FloatingActionButton(
                        onClick = onNavigateToNewChat,
                        containerColor = PakLightTeal,
                        contentColor = Color.White,
                        shape = CircleShape
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "New Call")
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
            when (selectedTab) {
                0 -> ChatsTab(
                    chats = filteredChats,
                    currentUserId = viewModel.currentUserId,
                    onChatClicked = { chat ->
                        val otherId = chat.getOtherParticipantId(viewModel.currentUserId)
                        onNavigateToChat(chat.chatId, otherId)
                    },
                    onStartFirstChat = onNavigateToNewChat
                )
                1 -> StatusTab(
                    currentUser = currentUser,
                    statuses = activeStatuses,
                    currentUserId = viewModel.currentUserId,
                    onMyStatusClicked = onNavigateToCreateStatus,
                    onStatusClicked = { status ->
                        onNavigateToStatusViewer(status.statusId)
                    }
                )
                2 -> CallsTab(
                    calls = callHistory,
                    currentUserId = viewModel.currentUserId,
                    onCallUser = { otherUserId, isVideo ->
                        val chatId = viewModel.userChats.value.firstOrNull {
                            it.participants.contains(otherUserId)
                        }?.chatId ?: ""
                        onNavigateToChat(chatId, otherUserId)
                    },
                    onStartCall = onNavigateToNewChat
                )
            }
        }
    }
}

@Composable
fun ChatsTab(
    chats: List<Chat>,
    currentUserId: String,
    onChatClicked: (Chat) -> Unit,
    onStartFirstChat: () -> Unit
) {
    if (chats.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.AddComment,
                contentDescription = null,
                tint = PakEmeraldGreen.copy(alpha = 0.5f),
                modifier = Modifier.size(72.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "No conversations yet",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Tap the chat button below to find registered Pak Chat users and start chatting in real time!",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    } else {
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(chats, key = { it.chatId }) { chat ->
                ChatItemRow(
                    chat = chat,
                    currentUserId = currentUserId,
                    onClick = { onChatClicked(chat) }
                )
            }
        }
    }
}

@Composable
fun ChatItemRow(
    chat: Chat,
    currentUserId: String,
    onClick: () -> Unit
) {
    val displayName = chat.getDisplayName(currentUserId)
    val displayPhoto = chat.getDisplayPhoto(currentUserId)
    val unreadCount = chat.getUnreadCount(currentUserId)
    val isTyping = chat.isOtherUserTyping(currentUserId)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        UserAvatar(photoUrl = displayPhoto, name = displayName, size = 52.dp)

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = displayName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = TimeUtils.formatChatListTime(chat.lastMessageTimestamp),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (unreadCount > 0) PakEmeraldGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = if (unreadCount > 0) FontWeight.Bold else FontWeight.Normal
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isTyping) {
                    Text(
                        text = "typing...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = PakLightTeal,
                        fontWeight = FontWeight.Medium
                    )
                } else {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (chat.lastMessageSenderId == currentUserId) {
                            MessageStatusIcon(status = "DELIVERED", modifier = Modifier.padding(end = 4.dp))
                        }
                        Text(
                            text = chat.lastMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                if (unreadCount > 0) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(PakEmeraldGreen)
                            .padding(horizontal = 7.dp, vertical = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (unreadCount > 99) "99+" else "$unreadCount",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatusTab(
    currentUser: com.pakchat.app.model.User?,
    statuses: List<StatusItem>,
    currentUserId: String,
    onMyStatusClicked: () -> Unit,
    onStatusClicked: (StatusItem) -> Unit
) {
    val myStatus = statuses.firstOrNull { it.userId == currentUserId && !it.isExpired() }
    val othersStatuses = statuses.filter { it.userId != currentUserId && !it.isExpired() }

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        // "My Status" Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onMyStatusClicked)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(contentAlignment = Alignment.BottomEnd) {
                    UserAvatar(
                        photoUrl = currentUser?.photoUrl,
                        name = currentUser?.displayName ?: "Me",
                        size = 52.dp
                    )
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(PakEmeraldGreen),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add status",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(text = "My Status", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text(
                        text = if (myStatus != null) "Tap to view update" else "Tap to add status update",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "Recent updates",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (othersStatuses.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No recent status updates from your contacts",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            items(othersStatuses, key = { it.statusId }) { status ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onStatusClicked(status) }
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(
                        photoUrl = status.userPhotoUrl,
                        name = status.userDisplayName,
                        size = 52.dp,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(PakLightTeal)
                            .padding(2.dp)
                    )

                    Spacer(modifier = Modifier.width(14.dp))

                    Column {
                        Text(text = status.userDisplayName, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Text(
                            text = TimeUtils.formatChatListTime(status.timestamp),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CallsTab(
    calls: List<CallRecord>,
    currentUserId: String,
    onCallUser: (otherUserId: String, isVideo: Boolean) -> Unit,
    onStartCall: () -> Unit
) {
    if (calls.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Call,
                contentDescription = null,
                tint = PakEmeraldGreen.copy(alpha = 0.5f),
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "No call history yet",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Audio and video calls with Pak Chat users will appear here.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    } else {
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(calls, key = { it.callId }) { call ->
                val isOutgoing = call.callerId == currentUserId
                val otherName = if (isOutgoing) call.receiverName else call.callerName
                val otherPhoto = if (isOutgoing) call.receiverPhoto else call.callerPhoto
                val otherId = if (isOutgoing) call.receiverId else call.callerId

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(photoUrl = otherPhoto, name = otherName, size = 48.dp)

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = otherName,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp,
                            color = if (call.status == CallStatus.MISSED.name) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onBackground
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isOutgoing) Icons.Default.CallMade else Icons.Default.CallReceived,
                                contentDescription = null,
                                tint = if (call.status == CallStatus.MISSED.name) MaterialTheme.colorScheme.error else PakEmeraldGreen,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = TimeUtils.formatChatListTime(call.timestamp),
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    IconButton(onClick = { onCallUser(otherId, call.callType == CallType.VIDEO.name) }) {
                        Icon(
                            imageVector = if (call.callType == CallType.VIDEO.name) Icons.Default.Videocam else Icons.Default.Call,
                            contentDescription = "Call",
                            tint = PakEmeraldGreen
                        )
                    }
                }
            }
        }
    }
}
