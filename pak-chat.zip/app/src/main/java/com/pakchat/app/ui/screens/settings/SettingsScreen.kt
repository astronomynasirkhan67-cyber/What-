package com.pakchat.app.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pakchat.app.ui.components.UserAvatar
import com.pakchat.app.ui.theme.PakDarkBackground
import com.pakchat.app.ui.theme.PakEmeraldGreen
import com.pakchat.app.ui.theme.PakGrayText
import com.pakchat.app.ui.theme.PakSurfaceDark
import com.pakchat.app.ui.viewmodel.HomeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: HomeViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onNavigateToPrivacy: () -> Unit,
    onSignOut: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    var infoDialogTitle by remember { mutableStateOf<String?>(null) }
    var infoDialogBody by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Settings",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PakSurfaceDark)
            )
        },
        containerColor = PakDarkBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
        ) {
            // Profile Card
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onNavigateToProfile)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                UserAvatar(
                    photoUrl = currentUser?.photoUrl,
                    displayName = currentUser?.displayName ?: "Me",
                    size = 64.dp
                )

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = currentUser?.displayName ?: "Pak Chat User",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = currentUser?.about ?: "Hey there! I am using Pak Chat.",
                        fontSize = 13.sp,
                        color = PakGrayText,
                        maxLines = 1
                    )
                }
            }

            HorizontalDivider(color = Color.DarkGray.copy(alpha = 0.3f), modifier = Modifier.padding(horizontal = 16.dp))

            Spacer(modifier = Modifier.height(8.dp))

            SettingsOptionRow(
                icon = Icons.Default.Lock,
                title = "Account & Privacy",
                subtitle = "Security, last seen, blocked contacts, delete account",
                onClick = onNavigateToPrivacy
            )

            SettingsOptionRow(
                icon = Icons.AutoMirrored.Filled.Chat,
                title = "Chats",
                subtitle = "Theme, wallpapers, chat history",
                onClick = {
                    infoDialogTitle = "Chats & Wallpapers"
                    infoDialogBody = "Default Dark Emerald Theme active.\n\nWallpaper: Pak Chat geometric chat background.\nFont Size: Medium\nEnter key sends message: Enabled."
                }
            )

            SettingsOptionRow(
                icon = Icons.Default.Notifications,
                title = "Notifications",
                subtitle = "Message, group & call tones, high priority preview",
                onClick = {
                    infoDialogTitle = "Notification Settings"
                    infoDialogBody = "Message Notifications: High Priority (Sound & Vibration)\nGroup Notifications: Enabled\nCall Ringtones: Pak Chat Ringtone\nReaction Alerts: Enabled."
                }
            )

            SettingsOptionRow(
                icon = Icons.Default.Storage,
                title = "Storage and data",
                subtitle = "Network usage, media auto-download",
                onClick = {
                    infoDialogTitle = "Storage & Data"
                    infoDialogBody = "Photos Auto-Download: Wi-Fi & Cellular\nVideos Auto-Download: Wi-Fi Only\nDocuments Auto-Download: Wi-Fi Only\nTotal Media Cache: 4.2 MB (Safe to keep)."
                }
            )

            SettingsOptionRow(
                icon = Icons.AutoMirrored.Filled.HelpOutline,
                title = "Help & About",
                subtitle = "Pak Chat v1.0.0 • Made with ❤️ for Pakistan 🇵🇰",
                onClick = {
                    infoDialogTitle = "About Pak Chat"
                    infoDialogBody = "Pak Chat v1.0.0 Production Release\n\nReal-time encrypted messaging, voice calls, video calls, status updates, and group chats.\n\nFirebase Cloud Messaging & Firestore Cloud Infrastructure."
                }
            )

            HorizontalDivider(color = Color.DarkGray.copy(alpha = 0.3f), modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))

            // Log out
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onSignOut)
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Logout,
                    contentDescription = "Log out",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(24.dp)
                )

                Spacer(modifier = Modifier.width(20.dp))

                Text(
                    text = "Log out",
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp
                )
            }
        }

        if (infoDialogTitle != null) {
            AlertDialog(
                onDismissRequest = { infoDialogTitle = null },
                title = { Text(infoDialogTitle!!, color = Color.White) },
                text = { Text(infoDialogBody ?: "", color = PakGrayText, fontSize = 14.sp) },
                confirmButton = {
                    TextButton(onClick = { infoDialogTitle = null }) {
                        Text("OK", color = PakEmeraldGreen)
                    }
                },
                containerColor = PakSurfaceDark
            )
        }
    }
}

@Composable
fun SettingsOptionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = PakEmeraldGreen,
            modifier = Modifier.size(24.dp)
        )

        Spacer(modifier = Modifier.width(20.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 13.sp,
                color = PakGrayText
            )
        }
    }
}
