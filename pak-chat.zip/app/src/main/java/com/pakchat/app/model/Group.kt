package com.pakchat.app.model

data class Group(
    val groupId: String = "",
    val name: String = "",
    val description: String = "",
    val iconUrl: String = "",
    val createdBy: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val adminIds: List<String> = emptyList(),
    val memberIds: List<String> = emptyList(),
    val lastMessage: String = "",
    val lastMessageTimestamp: Long = System.currentTimeMillis(),
    val lastMessageSenderId: String = "",
    val lastMessageType: String = MessageType.TEXT.name,
    val onlyAdminsCanMessage: Boolean = false,
    val onlyAdminsCanEditInfo: Boolean = false
) {
    fun isAdmin(userId: String): Boolean = adminIds.contains(userId)
    fun isMember(userId: String): Boolean = memberIds.contains(userId)
}

data class GroupMember(
    val uid: String = "",
    val displayName: String = "",
    val photoUrl: String = "",
    val phoneNumber: String = "",
    val role: String = GroupRole.MEMBER.name,
    val joinedAt: Long = System.currentTimeMillis()
)

enum class GroupRole {
    ADMIN,
    MEMBER
}
