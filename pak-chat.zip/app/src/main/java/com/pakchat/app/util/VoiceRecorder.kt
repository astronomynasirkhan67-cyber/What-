package com.pakchat.app.util

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import java.io.File
import java.io.IOException

class VoiceRecorder(private val context: Context) {
    private var mediaRecorder: MediaRecorder? = null
    private var outputFile: File? = null
    private var startTime: Long = 0L
    var isRecording: Boolean = false
        private set

    fun startRecording(): Boolean {
        try {
            val cacheDir = context.cacheDir
            outputFile = File(cacheDir, "voice_record_${System.currentTimeMillis()}.m4a")

            mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(44100)
                setAudioEncodingBitRate(96000)
                setOutputFile(outputFile?.absolutePath)
                prepare()
                start()
            }

            startTime = System.currentTimeMillis()
            isRecording = true
            return true
        } catch (e: Exception) {
            Log.e("VoiceRecorder", "Error starting voice recording", e)
            cancelRecording()
            return false
        }
    }

    fun stopRecording(): File? {
        if (!isRecording) return null
        return try {
            mediaRecorder?.apply {
                stop()
                release()
            }
            mediaRecorder = null
            isRecording = false
            outputFile
        } catch (e: Exception) {
            Log.e("VoiceRecorder", "Error stopping recording", e)
            cancelRecording()
            null
        }
    }

    fun cancelRecording() {
        try {
            if (isRecording) {
                mediaRecorder?.apply {
                    try { stop() } catch (_: Exception) {}
                    release()
                }
            }
        } catch (e: Exception) {
            Log.e("VoiceRecorder", "Error canceling recording", e)
        } finally {
            mediaRecorder = null
            isRecording = false
            outputFile?.delete()
            outputFile = null
        }
    }

    fun getRecordingDurationSeconds(): Int {
        if (!isRecording) return 0
        return ((System.currentTimeMillis() - startTime) / 1000).toInt()
    }
}
