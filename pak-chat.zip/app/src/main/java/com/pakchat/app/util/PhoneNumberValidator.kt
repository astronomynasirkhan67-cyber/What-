package com.pakchat.app.util

object PhoneNumberValidator {
    private const val PAKISTAN_COUNTRY_CODE = "+92"

    /**
     * Cleans and normalizes a Pakistani phone number into standard international E.164 format:
     * +923XXXXXXXXX
     */
    fun normalizePakistaniNumber(rawInput: String): String {
        val digitsOnly = rawInput.filter { it.isDigit() }
        return when {
            // Already starts with 92
            digitsOnly.startsWith("92") && digitsOnly.length >= 12 -> "+$digitsOnly"
            // Starts with 03 (e.g. 03001234567)
            digitsOnly.startsWith("03") && digitsOnly.length == 11 -> "+92" + digitsOnly.substring(1)
            // Starts with 3 (e.g. 3001234567)
            digitsOnly.startsWith("3") && digitsOnly.length == 10 -> "+92$digitsOnly"
            // Starts with +
            rawInput.startsWith("+") -> "+$digitsOnly"
            else -> "+92$digitsOnly"
        }
    }

    /**
     * Validates if the phone number matches Pakistani mobile pattern:
     * Standard Pakistan mobile numbers have 10 digits after +92 starting with '3'.
     * Total length: +92 followed by 10 digits (e.g. +923001234567).
     */
    fun isValidPakistaniNumber(normalizedNumber: String): Boolean {
        // Must start with +923 and have exactly 9 digits after 3 (total 13 chars)
        val regex = Regex("^\\+923[0-9]{9}$")
        return regex.matches(normalizedNumber)
    }

    /**
     * Formats normalized number for display:
     * +92 300 1234567
     */
    fun formatForDisplay(normalizedNumber: String): String {
        if (!isValidPakistaniNumber(normalizedNumber)) return normalizedNumber
        // +923001234567 -> +92 300 1234567
        val code = normalizedNumber.substring(0, 3)
        val prefix = normalizedNumber.substring(3, 6)
        val rest = normalizedNumber.substring(6)
        return "$code $prefix $rest"
    }
}
