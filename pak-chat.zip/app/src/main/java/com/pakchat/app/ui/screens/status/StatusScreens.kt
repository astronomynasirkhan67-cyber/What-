package com.pakchat.app.ui.screens.status

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SentimentSatisfiedAlt
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pakchat.app.data.repository.StatusRepository
import com.pakchat.app.model.StatusItem
import com.pakchat.app.ui.components.EmojiPickerSheet
import com.pakchat.app.ui.components.UserAvatar
import com.pakchat.app.ui.theme.PakEmeraldGreen
import com.pakchat.app.ui.theme.PakLightTeal
import com.pakchat.app.ui.viewmodel.HomeViewModel
import com.pakchat.app.util.TimeUtils
import kotlinx.coroutines.launch

@Composable
fun CreateStatusScreen(
    viewModel: HomeViewModel,
    onStatusPosted: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val scope = rememberCoroutineScope()
    val statusRepository = remember { StatusRepository() }

    val statusColors = listOf(
        Color(0xFF006A4E), // Pakistan Emerald
        Color(0xFF1E3A8A), // Royal Indigo
        Color(0xFF831843), // Crimson
        Color(0xFF4C1D95), // Deep Violet
        Color(0xFF78350F), // Warm Amber
        Color(0xFF111827)  // Dark Slate
    )

    var colorIndex by remember { mutableIntStateOf(0) }
    var statusText by remember { mutableStateOf("") }
    var showEmojiPicker by remember { mutableStateOf(false) }

    val currentColor = statusColors[colorIndex % statusColors.size]

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(currentColor)
    ) {
        // Top action buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp, start = 16.dp, end = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNavigateBack) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
            }

            Row {
                IconButton(onClick = { showEmojiPicker = !showEmojiPicker }) {
                    Icon(Icons.Default.SentimentSatisfiedAlt, contentDescription = "Emojis", tint = Color.White)
                }

                IconButton(onClick = { colorIndex++ }) {
                    Icon(Icons.Default.ColorLens, contentDescription = "Change color", tint = Color.White)
                }
            }
        }

        // Status Text Input
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            OutlinedTextField(
                value = statusText,
                onValueChange = { statusText = it },
                placeholder = {
                    Text(
                        text = "Type a status...",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 24.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                textStyle = TextStyle(
                    color = Color.White,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center
                ),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Floating Send Button
        if (statusText.isNotBlank()) {
            FloatingActionButton(
                onClick = {
                    val user = currentUser ?: return@FloatingActionButton
                    scope.launch {
                        val status = StatusItem(
                            userId = user.uid,
                            userDisplayName = user.displayName,
                            userPhotoUrl = user.photoUrl,
                            type = "TEXT",
                            content = statusText.trim(),
                            backgroundColor = currentColor.value.toLong(),
                            timestamp = System.currentTimeMillis()
                        )
                        statusRepository.postStatus(status)
                        onStatusPosted()
                    }
                },
                containerColor = PakLightTeal,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(24.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = "Post status")
            }
        }

        // Emoji picker
        if (showEmojiPicker) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
            ) {
                EmojiPickerSheet(
                    onEmojiPicked = { emoji ->
                        statusText += emoji
                    },
                    modifier = Modifier.height(260.dp)
                )
            }
        }
    }
}

@Composable
fun StatusViewerScreen(
    statusId: String,
    viewModel: HomeViewModel,
    onClose: () -> Unit
) {
    val activeStatuses by viewModel.activeStatuses.collectAsState()
    val status = activeStatuses.firstOrNull { it.statusId == statusId }
    val progress = remember { Animatable(0f) }
    val statusRepository = remember { StatusRepository() }

    LaunchedEffect(statusId) {
        if (status != null && viewModel.currentUserId.isNotBlank()) {
            statusRepository.markStatusViewed(statusId, viewModel.currentUserId)
        }
        progress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 5000, easing = LinearEasing)
        )
        onClose()
    }

    if (status == null) {
        onClose()
        return
    }

    val bgColor = Color(status.backgroundColor)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
            .clickable(onClick = onClose)
    ) {
        // Progress Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 40.dp, start = 16.dp, end = 16.dp)
        ) {
            LinearProgressIndicator(
                progress = { progress.value },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(CircleShape),
                color = Color.White,
                trackColor = Color.White.copy(alpha = 0.3f)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // User Info
            Row(verticalAlignment = Alignment.CenterVertically) {
                UserAvatar(photoUrl = status.userPhotoUrl, name = status.userDisplayName, size = 40.dp)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = status.userDisplayName,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 16.sp
                    )
                    Text(
                        text = TimeUtils.formatChatListTime(status.timestamp),
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }
        }

        // Status Content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = status.content,
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                lineHeight = 34.sp
            )
        }
    }
}
