package com.pakchat.app.ui.screens.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.pakchat.app.data.repository.UserRepository
import com.pakchat.app.model.PrivacySettings
import com.pakchat.app.ui.theme.PakDarkBackground
import com.pakchat.app.ui.theme.PakEmeraldGreen
import com.pakchat.app.ui.theme.PakGrayText
import com.pakchat.app.ui.theme.PakSurfaceDark
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacySettingsScreen(
    onNavigateBack: () -> Unit,
    onAccountDeleted: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val userRepository = remember { UserRepository() }
    val currentUserId = FirebaseAuth.getInstance().currentUser?.uid ?: ""

    val privacySettings by userRepository.getPrivacySettingsFlow(currentUserId).collectAsState(initial = PrivacySettings())

    var activeDialogType by remember { mutableStateOf<String?>(null) }
    var showDeleteAccountDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Privacy", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PakSurfaceDark)
            )
        },
        containerColor = PakDarkBackground
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            item {
                Text(
                    text = "Who can see my personal info",
                    color = PakEmeraldGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(16.dp)
                )
            }

            item {
                PrivacyOptionRow(
                    title = "Last seen and online",
                    subtitle = privacySettings.lastSeenVisibility,
                    onClick = { activeDialogType = "LAST_SEEN" }
                )
            }

            item {
                PrivacyOptionRow(
                    title = "Profile photo",
                    subtitle = privacySettings.profilePhotoVisibility,
                    onClick = { activeDialogType = "PROFILE_PHOTO" }
                )
            }

            item {
                PrivacyOptionRow(
                    title = "About",
                    subtitle = privacySettings.aboutVisibility,
                    onClick = { activeDialogType = "ABOUT" }
                )
            }

            item {
                PrivacyOptionRow(
                    title = "Status",
                    subtitle = privacySettings.statusVisibility,
                    onClick = { activeDialogType = "STATUS" }
                )
            }

            item {
                HorizontalDivider(color = Color.DarkGray.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 8.dp))
            }

            // Read Receipts Switch
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Read receipts", color = Color.White, fontSize = 16.sp)
                        Text(
                            "If turned off, you won't send or receive Read receipts (blue double ticks). Read receipts are always sent for group chats.",
                            color = PakGrayText,
                            fontSize = 13.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Switch(
                        checked = privacySettings.readReceipts,
                        onCheckedChange = { checked ->
                            coroutineScope.launch {
                                userRepository.updatePrivacySettings(currentUserId, privacySettings.copy(readReceipts = checked))
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = PakEmeraldGreen
                        )
                    )
                }
            }

            item {
                HorizontalDivider(color = Color.DarkGray.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 8.dp))
            }

            item {
                Text(
                    text = "Disappearing messages & Security",
                    color = PakEmeraldGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(16.dp)
                )
            }

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { activeDialogType = "BLOCKED" }
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Block, contentDescription = null, tint = PakGrayText)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("Blocked contacts", color = Color.White, fontSize = 16.sp)
                        Text(
                            "${privacySettings.blockedUsers.size} contacts blocked",
                            color = PakGrayText,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            item {
                HorizontalDivider(color = Color.DarkGray.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 8.dp))
            }

            // Delete Account Danger Zone
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showDeleteAccountDialog = true }
                        .padding(horizontal = 16.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text("Delete my account", color = MaterialTheme.colorScheme.error, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                        Text("Permanently delete your profile and account data", color = PakGrayText, fontSize = 13.sp)
                    }
                }
            }
        }

        // Selection Dialog for Visibility Options
        if (activeDialogType in listOf("LAST_SEEN", "PROFILE_PHOTO", "ABOUT", "STATUS")) {
            val options = listOf("Everyone", "My Contacts", "Nobody")
            val currentVal = when (activeDialogType) {
                "LAST_SEEN" -> privacySettings.lastSeenVisibility
                "PROFILE_PHOTO" -> privacySettings.profilePhotoVisibility
                "ABOUT" -> privacySettings.aboutVisibility
                "STATUS" -> privacySettings.statusVisibility
                else -> "Everyone"
            }

            AlertDialog(
                onDismissRequest = { activeDialogType = null },
                title = {
                    Text(
                        text = when (activeDialogType) {
                            "LAST_SEEN" -> "Last Seen & Online"
                            "PROFILE_PHOTO" -> "Profile Photo"
                            "ABOUT" -> "About"
                            "STATUS" -> "Status"
                            else -> "Visibility"
                        },
                        color = Color.White
                    )
                },
                text = {
                    Column {
                        options.forEach { option ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        coroutineScope.launch {
                                            val updated = when (activeDialogType) {
                                                "LAST_SEEN" -> privacySettings.copy(lastSeenVisibility = option)
                                                "PROFILE_PHOTO" -> privacySettings.copy(profilePhotoVisibility = option)
                                                "ABOUT" -> privacySettings.copy(aboutVisibility = option)
                                                "STATUS" -> privacySettings.copy(statusVisibility = option)
                                                else -> privacySettings
                                            }
                                            userRepository.updatePrivacySettings(currentUserId, updated)
                                            activeDialogType = null
                                        }
                                    }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = (option == currentVal),
                                    onClick = null,
                                    colors = RadioButtonDefaults.colors(selectedColor = PakEmeraldGreen)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(option, color = Color.White, fontSize = 16.sp)
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { activeDialogType = null }) {
                        Text("Cancel", color = PakEmeraldGreen)
                    }
                },
                containerColor = PakSurfaceDark
            )
        }

        // Blocked contacts dialog
        if (activeDialogType == "BLOCKED") {
            AlertDialog(
                onDismissRequest = { activeDialogType = null },
                title = { Text("Blocked Contacts", color = Color.White) },
                text = {
                    if (privacySettings.blockedUsers.isEmpty()) {
                        Text("No blocked contacts.", color = PakGrayText)
                    } else {
                        Column {
                            privacySettings.blockedUsers.forEach { blockedUid ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(blockedUid.take(12) + "...", color = Color.White, modifier = Modifier.weight(1f))
                                    TextButton(
                                        onClick = {
                                            coroutineScope.launch {
                                                userRepository.unblockUser(currentUserId, blockedUid)
                                            }
                                        }
                                    ) {
                                        Text("Unblock", color = PakEmeraldGreen)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { activeDialogType = null }) {
                        Text("Done", color = PakEmeraldGreen)
                    }
                },
                containerColor = PakSurfaceDark
            )
        }

        // Delete Account Confirm Dialog
        if (showDeleteAccountDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteAccountDialog = false },
                title = { Text("Delete your account?", color = Color.White) },
                text = {
                    Text(
                        "Deleting your account will delete your account info, profile photo, and message history from Pak Chat. This action cannot be undone.",
                        color = PakGrayText
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            coroutineScope.launch {
                                val result = userRepository.deleteAccount(currentUserId)
                                showDeleteAccountDialog = false
                                if (result.isSuccess) {
                                    onAccountDeleted()
                                }
                            }
                        }
                    ) {
                        Text("Delete", color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteAccountDialog = false }) {
                        Text("Cancel", color = Color.White)
                    }
                },
                containerColor = PakSurfaceDark
            )
        }
    }
}

@Composable
private fun PrivacyOptionRow(
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(title, color = Color.White, fontSize = 16.sp)
        Spacer(modifier = Modifier.height(2.dp))
        Text(subtitle, color = PakGrayText, fontSize = 14.sp)
    }
}
