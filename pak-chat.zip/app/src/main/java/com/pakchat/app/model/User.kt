package com.pakchat.app.model

data class User(
    val uid: String = "",
    val phoneNumber: String = "",
    val displayName: String = "",
    val photoUrl: String = "",
    val about: String = "Hey there! I am using Pak Chat.",
    val createdAt: Long = System.currentTimeMillis(),
    val lastSeen: Long = System.currentTimeMillis(),
    val isOnline: Boolean = false,
    val fcmToken: String = "",
    val blockedUsers: List<String> = emptyList()
)
