package com.pakchat.app.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object TimeUtils {

    fun formatMessageTime(timestamp: Long): String {
        if (timestamp <= 0) return ""
        val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun formatChatListTime(timestamp: Long): String {
        if (timestamp <= 0) return ""
        val now = Calendar.getInstance()
        val messageCal = Calendar.getInstance().apply { timeInMillis = timestamp }

        val isSameDay = now.get(Calendar.YEAR) == messageCal.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) == messageCal.get(Calendar.DAY_OF_YEAR)

        if (isSameDay) {
            return formatMessageTime(timestamp)
        }

        val yesterdayCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val isYesterday = yesterdayCal.get(Calendar.YEAR) == messageCal.get(Calendar.YEAR) &&
                yesterdayCal.get(Calendar.DAY_OF_YEAR) == messageCal.get(Calendar.DAY_OF_YEAR)

        if (isYesterday) {
            return "Yesterday"
        }

        val daysDiff = (now.timeInMillis - timestamp) / (1000 * 60 * 60 * 24)
        return if (daysDiff < 7) {
            val sdf = SimpleDateFormat("EEEE", Locale.getDefault())
            sdf.format(Date(timestamp))
        } else {
            val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
            sdf.format(Date(timestamp))
        }
    }

    fun formatLastSeen(timestamp: Long, isOnline: Boolean): String {
        if (isOnline) return "Online"
        if (timestamp <= 0) return "Offline"

        val now = Calendar.getInstance()
        val seenCal = Calendar.getInstance().apply { timeInMillis = timestamp }

        val diffMinutes = (now.timeInMillis - timestamp) / (1000 * 60)
        if (diffMinutes < 1) return "Last seen just now"
        if (diffMinutes < 60) return "Last seen $diffMinutes minutes ago"

        val isSameDay = now.get(Calendar.YEAR) == seenCal.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) == seenCal.get(Calendar.DAY_OF_YEAR)

        val timeStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(timestamp))
        if (isSameDay) {
            return "Last seen today at $timeStr"
        }

        val yesterdayCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val isYesterday = yesterdayCal.get(Calendar.YEAR) == seenCal.get(Calendar.YEAR) &&
                yesterdayCal.get(Calendar.DAY_OF_YEAR) == seenCal.get(Calendar.DAY_OF_YEAR)

        if (isYesterday) {
            return "Last seen yesterday at $timeStr"
        }

        val dateStr = SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(Date(timestamp))
        return "Last seen $dateStr at $timeStr"
    }

    fun formatDateHeader(timestamp: Long): String {
        if (timestamp <= 0) return ""
        val now = Calendar.getInstance()
        val messageCal = Calendar.getInstance().apply { timeInMillis = timestamp }

        val isSameDay = now.get(Calendar.YEAR) == messageCal.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) == messageCal.get(Calendar.DAY_OF_YEAR)

        if (isSameDay) return "Today"

        val yesterdayCal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        val isYesterday = yesterdayCal.get(Calendar.YEAR) == messageCal.get(Calendar.YEAR) &&
                yesterdayCal.get(Calendar.DAY_OF_YEAR) == messageCal.get(Calendar.DAY_OF_YEAR)

        if (isYesterday) return "Yesterday"

        val sdf = SimpleDateFormat("MMMM d, yyyy", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun formatDuration(seconds: Int): String {
        val mins = seconds / 60
        val secs = seconds % 60
        return String.format(Locale.getDefault(), "%d:%02d", mins, secs)
    }
}
