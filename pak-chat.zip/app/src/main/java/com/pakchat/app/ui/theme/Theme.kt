package com.pakchat.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = PakEmeraldGreen,
    onPrimary = Color.White,
    primaryContainer = PakMintBubble,
    onPrimaryContainer = PakDarkTeal,
    secondary = PakLightTeal,
    onSecondary = Color.White,
    secondaryContainer = PakLightGray,
    onSecondaryContainer = PakTextPrimary,
    background = Color(0xFFF7F8FA),
    onBackground = PakTextPrimary,
    surface = Color.White,
    onSurface = PakTextPrimary,
    surfaceVariant = PakLightGray,
    onSurfaceVariant = PakTextSecondary,
    outline = PakBorder
)

private val DarkColorScheme = darkColorScheme(
    primary = PakLightTeal,
    onPrimary = Color.White,
    primaryContainer = PakDarkOutgoingBubble,
    onPrimaryContainer = PakDarkTextPrimary,
    secondary = PakLightTeal,
    onSecondary = Color.White,
    secondaryContainer = PakDarkSurfaceVariant,
    onSecondaryContainer = PakDarkTextPrimary,
    background = PakDarkBackground,
    onBackground = PakDarkTextPrimary,
    surface = PakDarkSurface,
    onSurface = PakDarkTextPrimary,
    surfaceVariant = PakDarkSurfaceVariant,
    onSurfaceVariant = PakDarkTextSecondary,
    outline = PakDarkBorder
)

@Composable
fun PakChatTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
