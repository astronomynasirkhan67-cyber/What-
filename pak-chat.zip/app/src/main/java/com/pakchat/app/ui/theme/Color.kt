package com.pakchat.app.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val PakEmeraldGreen = Color(0xFF006A4E)
val PakDarkTeal = Color(0xFF075E54)
val PakLightTeal = Color(0xFF00A884)
val PakMintBubble = Color(0xFFE7FFDB)
val PakLightGray = Color(0xFFF0F2F5)
val PakTextPrimary = Color(0xFF111B21)
val PakTextSecondary = Color(0xFF667781)
val PakBorder = Color(0xFFE9EDEF)
val PakIncomingBubbleLight = Color(0xFFFFFFFF)
val PakReadBlue = Color(0xFF53BDEB)

// Dark Theme Colors
val PakDarkBackground = Color(0xFF0B141A)
val PakDarkSurface = Color(0xFF111B21)
val PakSurfaceDark = Color(0xFF111B21)
val PakDarkSurfaceVariant = Color(0xFF202C33)
val PakDarkOutgoingBubble = Color(0xFF005C4B)
val PakDarkIncomingBubble = Color(0xFF202C33)
val PakDarkTextPrimary = Color(0xFFE9EDEF)
val PakDarkTextSecondary = Color(0xFF8696A0)
val PakGrayText = Color(0xFF8696A0)
val PakDarkBorder = Color(0xFF222D34)
