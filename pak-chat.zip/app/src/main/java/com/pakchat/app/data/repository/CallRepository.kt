package com.pakchat.app.data.repository

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.pakchat.app.model.CallRecord
import com.pakchat.app.model.CallStatus
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class CallRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    private val callsCollection = firestore.collection("calls")

    suspend fun initiateCall(callRecord: CallRecord): Result<String> {
        return try {
            val callId = if (callRecord.callId.isBlank()) UUID.randomUUID().toString() else callRecord.callId
            val finalCall = callRecord.copy(callId = callId)
            callsCollection.document(callId).set(finalCall).await()
            Result.success(callId)
        } catch (e: Exception) {
            Log.e("CallRepository", "Failed to initiate call", e)
            Result.failure(e)
        }
    }

    fun listenToIncomingCallFlow(currentUserId: String): Flow<CallRecord?> = callbackFlow {
        val listener = callsCollection
            .whereEqualTo("receiverId", currentUserId)
            .whereEqualTo("status", CallStatus.RINGING.name)
            .limit(1)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("CallRepository", "Error listening for incoming calls", error)
                    trySend(null)
                    return@addSnapshotListener
                }

                val incomingCall = snapshot?.documents?.firstOrNull()?.toObject(CallRecord::class.java)
                trySend(incomingCall)
            }

        awaitClose { listener.remove() }
    }

    fun getCallFlow(callId: String): Flow<CallRecord?> = callbackFlow {
        val listener = callsCollection.document(callId).addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.e("CallRepository", "Error listening to call $callId", error)
                trySend(null)
                return@addSnapshotListener
            }
            trySend(snapshot?.toObject(CallRecord::class.java))
        }
        awaitClose { listener.remove() }
    }

    suspend fun updateCallStatus(callId: String, status: CallStatus, durationSeconds: Int = 0) {
        try {
            val updates = mutableMapOf<String, Any>("status" to status.name)
            if (durationSeconds > 0) {
                updates["durationSeconds"] = durationSeconds
            }
            callsCollection.document(callId).update(updates).await()
        } catch (e: Exception) {
            Log.e("CallRepository", "Failed to update call status", e)
        }
    }

    fun getCallHistoryFlow(currentUserId: String): Flow<List<CallRecord>> = callbackFlow {
        val listener = callsCollection
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .limit(50)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("CallRepository", "Error getting call history", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }

                val calls = snapshot?.documents?.mapNotNull { it.toObject(CallRecord::class.java) }
                    ?.filter { it.callerId == currentUserId || it.receiverId == currentUserId }
                    ?: emptyList()

                trySend(calls)
            }

        awaitClose { listener.remove() }
    }

    // WebRTC Signaling methods
    suspend fun setOffer(callId: String, sdp: String) {
        try {
            callsCollection.document(callId).update("offerSdp", sdp).await()
        } catch (e: Exception) {
            Log.e("CallRepository", "Failed to set offer", e)
        }
    }

    suspend fun setAnswer(callId: String, sdp: String) {
        try {
            callsCollection.document(callId).update("answerSdp", sdp).await()
        } catch (e: Exception) {
            Log.e("CallRepository", "Failed to set answer", e)
        }
    }

    suspend fun addIceCandidate(callId: String, isCaller: Boolean, sdpMid: String, sdpMLineIndex: Int, candidate: String) {
        try {
            val candidateData = mapOf(
                "isCaller" to isCaller,
                "sdpMid" to sdpMid,
                "sdpMLineIndex" to sdpMLineIndex,
                "candidate" to candidate,
                "timestamp" to System.currentTimeMillis()
            )
            callsCollection.document(callId).collection("candidates").add(candidateData).await()
        } catch (e: Exception) {
            Log.e("CallRepository", "Failed to add ICE candidate", e)
        }
    }

    fun getIceCandidatesFlow(callId: String, forCaller: Boolean): Flow<List<Map<String, Any>>> = callbackFlow {
        val listener = callsCollection.document(callId).collection("candidates")
            .whereEqualTo("isCaller", !forCaller) // get other party's candidates
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.documents?.mapNotNull { it.data } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }
}
