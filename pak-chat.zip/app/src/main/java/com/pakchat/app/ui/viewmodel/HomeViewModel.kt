package com.pakchat.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.pakchat.app.data.repository.CallRepository
import com.pakchat.app.data.repository.ChatRepository
import com.pakchat.app.data.repository.GroupRepository
import com.pakchat.app.data.repository.StatusRepository
import com.pakchat.app.data.repository.UserRepository
import com.pakchat.app.model.CallRecord
import com.pakchat.app.model.Chat
import com.pakchat.app.model.Group
import com.pakchat.app.model.StatusItem
import com.pakchat.app.model.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(
    private val userRepository: UserRepository = UserRepository(),
    private val chatRepository: ChatRepository = ChatRepository(),
    private val groupRepository: GroupRepository = GroupRepository(),
    private val statusRepository: StatusRepository = StatusRepository(),
    private val callRepository: CallRepository = CallRepository()
) : ViewModel() {

    val currentUserId: String = FirebaseAuth.getInstance().currentUser?.uid ?: ""

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isSearchActive = MutableStateFlow(false)
    val isSearchActive: StateFlow<Boolean> = _isSearchActive.asStateFlow()

    private val _selectedTab = MutableStateFlow(0) // 0: CHATS, 1: STATUS, 2: CALLS
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    val userChats: StateFlow<List<Chat>> = chatRepository.getUserChatsFlow(currentUserId)
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val userGroups: StateFlow<List<Group>> = groupRepository.getUserGroupsFlow(currentUserId)
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Merged unified chats list (Direct chats + Group chats)
    val allUnifiedChats: StateFlow<List<Chat>> = combine(userChats, userGroups) { chats, groups ->
        val groupChatItems = groups.map { g ->
            Chat(
                chatId = g.groupId,
                participants = g.memberIds,
                participantNames = mapOf(g.groupId to g.name),
                participantPhotos = if (g.iconUrl.isNotBlank()) mapOf(g.groupId to g.iconUrl) else emptyMap(),
                lastMessage = g.lastMessage,
                lastMessageTimestamp = if (g.lastMessageTimestamp > 0) g.lastMessageTimestamp else g.createdAt,
                isGroup = true,
                groupName = g.name,
                groupIcon = g.iconUrl
            )
        }
        (chats + groupChatItems).sortedByDescending { it.lastMessageTimestamp }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val filteredChats: StateFlow<List<Chat>> = combine(allUnifiedChats, _searchQuery) { chats, query ->
        if (query.isBlank()) {
            chats
        } else {
            chats.filter { chat ->
                chat.getDisplayName(currentUserId).contains(query, ignoreCase = true) ||
                        chat.lastMessage.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val activeStatuses: StateFlow<List<StatusItem>> = statusRepository.getAllActiveStatusesFlow()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val callHistory: StateFlow<List<CallRecord>> = callRepository.getCallHistoryFlow(currentUserId)
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val allRegisteredUsers: StateFlow<List<User>> = userRepository.getAllUsersFlow(currentUserId)
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    init {
        loadCurrentUser()
    }

    private fun loadCurrentUser() {
        if (currentUserId.isNotBlank()) {
            viewModelScope.launch {
                userRepository.getUserFlow(currentUserId).collect { user ->
                    _currentUser.value = user
                }
            }
        }
    }

    fun setSelectedTab(index: Int) {
        _selectedTab.value = index
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleSearch() {
        _isSearchActive.value = !_isSearchActive.value
        if (!_isSearchActive.value) {
            _searchQuery.value = ""
        }
    }

    fun startChatWithUser(targetUser: User, onChatReady: (String) -> Unit) {
        val current = _currentUser.value ?: return
        viewModelScope.launch {
            val chatId = chatRepository.getOrCreateOneToOneChat(current, targetUser)
            onChatReady(chatId)
        }
    }
}
