package com.pakchat.app.data.repository

import android.app.Activity
import android.util.Log
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

class AuthRepository(private val auth: FirebaseAuth = FirebaseAuth.getInstance()) {

    interface OtpCallback {
        fun onCodeSent(verificationId: String, token: PhoneAuthProvider.ForceResendingToken)
        fun onVerificationCompleted(credential: PhoneAuthCredential)
        fun onVerificationFailed(exception: FirebaseException)
    }

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    val currentUserId: String?
        get() = auth.currentUser?.uid

    fun isUserLoggedIn(): Boolean = auth.currentUser != null

    fun sendOtp(
        phoneNumber: String,
        activity: Activity,
        callback: OtpCallback,
        resendToken: PhoneAuthProvider.ForceResendingToken? = null
    ) {
        val optionsBuilder = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneNumber)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    Log.d("AuthRepository", "Verification auto-completed: $credential")
                    callback.onVerificationCompleted(credential)
                }

                override fun onVerificationFailed(e: FirebaseException) {
                    Log.e("AuthRepository", "Verification failed", e)
                    callback.onVerificationFailed(e)
                }

                override fun onCodeSent(
                    verificationId: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    Log.d("AuthRepository", "Code sent: $verificationId")
                    callback.onCodeSent(verificationId, token)
                }
            })

        if (resendToken != null) {
            optionsBuilder.setForceResendingToken(resendToken)
        }

        PhoneAuthProvider.verifyPhoneNumber(optionsBuilder.build())
    }

    suspend fun signInWithCredential(credential: PhoneAuthCredential): Result<FirebaseUser> {
        return try {
            val result = auth.signInWithCredential(credential).await()
            val user = result.user
            if (user != null) {
                Result.success(user)
            } else {
                Result.failure(Exception("Failed to get authenticated user"))
            }
        } catch (e: Exception) {
            Log.e("AuthRepository", "Sign-in with credential failed", e)
            Result.failure(e)
        }
    }

    suspend fun verifyOtpCode(verificationId: String, otpCode: String): Result<FirebaseUser> {
        return try {
            val credential = PhoneAuthProvider.getCredential(verificationId, otpCode)
            signInWithCredential(credential)
        } catch (e: Exception) {
            Log.e("AuthRepository", "OTP verification failed", e)
            Result.failure(e)
        }
    }

    /**
     * Fallback authentication for development testing on emulators or when SMS quota / Play Integrity
     * is not configured in the Firebase Console yet.
     */
    suspend fun devSignInWithCustomId(customUid: String): Result<FirebaseUser> {
        return try {
            // If already signed in with matching UID, return it
            val current = auth.currentUser
            if (current != null) {
                return Result.success(current)
            }
            // Use signInAnonymously as local fallback session if needed
            val authResult = auth.signInAnonymously().await()
            val user = authResult.user
            if (user != null) {
                Result.success(user)
            } else {
                Result.failure(Exception("Could not initialize session"))
            }
        } catch (e: Exception) {
            Log.e("AuthRepository", "Dev sign-in error", e)
            Result.failure(e)
        }
    }

    fun signOut() {
        auth.signOut()
    }
}
