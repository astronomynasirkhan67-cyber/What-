package com.pakchat.app.data.repository

import android.net.Uri
import android.util.Log
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import com.pakchat.app.model.Group
import com.pakchat.app.model.GroupMember
import com.pakchat.app.model.GroupRole
import com.pakchat.app.model.Message
import com.pakchat.app.model.MessageType
import com.pakchat.app.model.User
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.io.File
import java.util.UUID

class GroupRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val storage: FirebaseStorage = FirebaseStorage.getInstance()
) {

    private val groupsCollection = firestore.collection("groups")

    suspend fun createGroup(
        name: String,
        description: String,
        iconFile: File?,
        creator: User,
        initialMembers: List<User>
    ): Result<String> {
        return try {
            val groupId = "group_${UUID.randomUUID()}"
            var iconUrl = ""

            if (iconFile != null && iconFile.exists()) {
                val ref = storage.reference.child("group_icons/$groupId.jpg")
                ref.putFile(Uri.fromFile(iconFile)).await()
                iconUrl = ref.downloadUrl.await().toString()
            }

            val allMembers = (listOf(creator) + initialMembers).distinctBy { it.uid }
            val memberIds = allMembers.map { it.uid }
            val adminIds = listOf(creator.uid)

            val group = Group(
                groupId = groupId,
                name = name,
                description = description,
                iconUrl = iconUrl,
                createdBy = creator.uid,
                createdAt = System.currentTimeMillis(),
                adminIds = adminIds,
                memberIds = memberIds,
                lastMessage = "${creator.displayName} created group \"$name\"",
                lastMessageTimestamp = System.currentTimeMillis(),
                lastMessageSenderId = creator.uid,
                lastMessageType = MessageType.SYSTEM.name
            )

            // Write group doc
            groupsCollection.document(groupId).set(group).await()

            // Write member docs in subcollection
            val membersCollection = groupsCollection.document(groupId).collection("members")
            for (user in allMembers) {
                val role = if (user.uid == creator.uid) GroupRole.ADMIN.name else GroupRole.MEMBER.name
                val member = GroupMember(
                    uid = user.uid,
                    displayName = user.displayName,
                    photoUrl = user.photoUrl,
                    phoneNumber = user.phoneNumber,
                    role = role,
                    joinedAt = System.currentTimeMillis()
                )
                membersCollection.document(user.uid).set(member).await()
            }

            // Write initial system message
            val systemMessage = Message(
                messageId = UUID.randomUUID().toString(),
                senderId = creator.uid,
                chatId = groupId,
                text = "${creator.displayName} created group \"$name\"",
                messageType = MessageType.SYSTEM.name,
                timestamp = System.currentTimeMillis()
            )
            groupsCollection.document(groupId).collection("messages").document(systemMessage.messageId).set(systemMessage).await()

            Result.success(groupId)
        } catch (e: Exception) {
            Log.e("GroupRepository", "Failed to create group", e)
            Result.failure(e)
        }
    }

    fun getUserGroupsFlow(currentUserId: String): Flow<List<Group>> = callbackFlow {
        val listener = groupsCollection
            .whereArrayContains("memberIds", currentUserId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("GroupRepository", "Error getting user groups", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }

                val groups = snapshot?.documents?.mapNotNull { it.toObject(Group::class.java) }
                    ?.sortedByDescending { it.lastMessageTimestamp }
                    ?: emptyList()

                trySend(groups)
            }

        awaitClose { listener.remove() }
    }

    fun getGroupFlow(groupId: String): Flow<Group?> = callbackFlow {
        val listener = groupsCollection.document(groupId).addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.e("GroupRepository", "Error listening to group $groupId", error)
                trySend(null)
                return@addSnapshotListener
            }
            trySend(snapshot?.toObject(Group::class.java))
        }
        awaitClose { listener.remove() }
    }

    fun getGroupMembersFlow(groupId: String): Flow<List<GroupMember>> = callbackFlow {
        val listener = groupsCollection.document(groupId).collection("members")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("GroupRepository", "Error getting group members", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }

                val members = snapshot?.documents?.mapNotNull { it.toObject(GroupMember::class.java) }
                    ?.sortedBy { if (it.role == GroupRole.ADMIN.name) 0 else 1 }
                    ?: emptyList()

                trySend(members)
            }

        awaitClose { listener.remove() }
    }

    fun getGroupMessagesFlow(groupId: String, limit: Long = 100): Flow<List<Message>> = callbackFlow {
        val messagesRef = groupsCollection.document(groupId).collection("messages")
        val listener = messagesRef
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .limitToLast(limit)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("GroupRepository", "Error observing group messages $groupId", error)
                    trySend(emptyList())
                    return@addSnapshotListener
                }

                val messages = snapshot?.documents?.mapNotNull { it.toObject(Message::class.java) }
                    ?: emptyList()

                trySend(messages)
            }

        awaitClose { listener.remove() }
    }

    suspend fun sendGroupMessage(groupId: String, message: Message): Result<Unit> {
        return try {
            val messageId = if (message.messageId.isBlank()) UUID.randomUUID().toString() else message.messageId
            val finalMessage = message.copy(messageId = messageId, chatId = groupId)

            val groupRef = groupsCollection.document(groupId)
            val msgRef = groupRef.collection("messages").document(messageId)

            firestore.runBatch { batch ->
                batch.set(msgRef, finalMessage)

                val preview = when (message.messageType) {
                    MessageType.IMAGE.name -> "📷 Photo"
                    MessageType.VOICE.name -> "🎤 Voice message"
                    MessageType.VIDEO.name -> "🎥 Video"
                    MessageType.DOCUMENT.name -> "📄 Document"
                    else -> message.text
                }

                batch.update(
                    groupRef,
                    mapOf(
                        "lastMessage" to preview,
                        "lastMessageTimestamp" to message.timestamp,
                        "lastMessageSenderId" to message.senderId,
                        "lastMessageType" to message.messageType
                    )
                )
            }.await()

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("GroupRepository", "Failed to send group message", e)
            Result.failure(e)
        }
    }

    suspend fun addMember(groupId: String, user: User, role: GroupRole = GroupRole.MEMBER) {
        try {
            val groupRef = groupsCollection.document(groupId)
            val member = GroupMember(
                uid = user.uid,
                displayName = user.displayName,
                photoUrl = user.photoUrl,
                phoneNumber = user.phoneNumber,
                role = role.name,
                joinedAt = System.currentTimeMillis()
            )

            groupRef.collection("members").document(user.uid).set(member).await()
            groupRef.update("memberIds", FieldValue.arrayUnion(user.uid)).await()
        } catch (e: Exception) {
            Log.e("GroupRepository", "Failed to add member", e)
        }
    }

    suspend fun removeMember(groupId: String, uid: String) {
        try {
            val groupRef = groupsCollection.document(groupId)
            groupRef.collection("members").document(uid).delete().await()
            groupRef.update(
                mapOf(
                    "memberIds" to FieldValue.arrayRemove(uid),
                    "adminIds" to FieldValue.arrayRemove(uid)
                )
            ).await()
        } catch (e: Exception) {
            Log.e("GroupRepository", "Failed to remove member", e)
        }
    }

    suspend fun setAdminRole(groupId: String, uid: String, isAdmin: Boolean) {
        try {
            val groupRef = groupsCollection.document(groupId)
            val role = if (isAdmin) GroupRole.ADMIN.name else GroupRole.MEMBER.name
            groupRef.collection("members").document(uid).update("role", role).await()

            if (isAdmin) {
                groupRef.update("adminIds", FieldValue.arrayUnion(uid)).await()
            } else {
                groupRef.update("adminIds", FieldValue.arrayRemove(uid)).await()
            }
        } catch (e: Exception) {
            Log.e("GroupRepository", "Failed to set admin role", e)
        }
    }

    suspend fun updateGroupSettings(
        groupId: String,
        name: String,
        description: String,
        onlyAdminsCanMessage: Boolean
    ) {
        try {
            groupsCollection.document(groupId).update(
                mapOf(
                    "name" to name,
                    "description" to description,
                    "onlyAdminsCanMessage" to onlyAdminsCanMessage
                )
            ).await()
        } catch (e: Exception) {
            Log.e("GroupRepository", "Failed to update group settings", e)
        }
    }

    suspend fun uploadGroupMedia(groupId: String, file: File, extension: String): Result<String> {
        return try {
            val fileName = "${UUID.randomUUID()}.$extension"
            val ref = storage.reference.child("group_media/$groupId/$fileName")
            ref.putFile(Uri.fromFile(file)).await()
            val downloadUrl = ref.downloadUrl.await().toString()
            Result.success(downloadUrl)
        } catch (e: Exception) {
            Log.e("GroupRepository", "Failed to upload group media", e)
            Result.failure(e)
        }
    }
}
