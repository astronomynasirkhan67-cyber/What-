package com.pakchat.app.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import com.pakchat.app.MainActivity
import com.pakchat.app.R
import com.pakchat.app.data.repository.UserRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class PakChatMessagingService : FirebaseMessagingService() {

    companion object {
        const val CHANNEL_MESSAGES_ID = "pak_chat_messages"
        const val CHANNEL_MESSAGES_NAME = "Pak Chat Messages"
        const val CHANNEL_CALLS_ID = "pak_chat_calls"
        const val CHANNEL_CALLS_NAME = "Pak Chat Calls"

        fun createNotificationChannels(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val notificationManager =
                    context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

                val messageChannel = NotificationChannel(
                    CHANNEL_MESSAGES_ID,
                    CHANNEL_MESSAGES_NAME,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Notifications for incoming Pak Chat messages"
                    enableVibration(true)
                }

                val callChannel = NotificationChannel(
                    CHANNEL_CALLS_ID,
                    CHANNEL_CALLS_NAME,
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Notifications for incoming Pak Chat calls"
                    enableVibration(true)
                }

                notificationManager.createNotificationChannel(messageChannel)
                notificationManager.createNotificationChannel(callChannel)
            }
        }
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("FCM", "Refreshed FCM token: $token")
        val currentUid = FirebaseAuth.getInstance().currentUser?.uid
        if (currentUid != null) {
            CoroutineScope(Dispatchers.IO).launch {
                UserRepository().updateFcmToken(currentUid, token)
            }
        }
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        val title = remoteMessage.data["title"] ?: remoteMessage.notification?.title ?: "Pak Chat"
        val body = remoteMessage.data["body"] ?: remoteMessage.notification?.body ?: "New message"
        val chatId = remoteMessage.data["chatId"]
        val senderId = remoteMessage.data["senderId"]

        sendNotification(title, body, chatId, senderId)
    }

    private fun sendNotification(title: String, messageBody: String, chatId: String?, senderId: String?) {
        createNotificationChannels(this)

        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("chatId", chatId)
            putExtra("senderId", senderId)
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            System.currentTimeMillis().toInt(),
            intent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )

        val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val notificationBuilder = NotificationCompat.Builder(this, CHANNEL_MESSAGES_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(messageBody)
            .setAutoCancel(true)
            .setSound(defaultSoundUri)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationId = (chatId?.hashCode() ?: System.currentTimeMillis().toInt())
        notificationManager.notify(notificationId, notificationBuilder.build())
    }
}
