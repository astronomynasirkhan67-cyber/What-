package com.pakchat.app.data.repository

import android.net.Uri
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import com.pakchat.app.model.PrivacySettings
import com.pakchat.app.model.User
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.io.File

class UserRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val storage: FirebaseStorage = FirebaseStorage.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {

    private val usersCollection = firestore.collection("users")

    suspend fun saveUser(user: User): Result<Unit> {
        return try {
            usersCollection.document(user.uid)
                .set(user, SetOptions.merge())
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("UserRepository", "Error saving user profile", e)
            Result.failure(e)
        }
    }

    fun getUserFlow(uid: String): Flow<User?> = callbackFlow {
        val listener = usersCollection.document(uid).addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.e("UserRepository", "Error listening to user: $uid", error)
                trySend(null)
                return@addSnapshotListener
            }
            if (snapshot != null && snapshot.exists()) {
                val user = snapshot.toObject(User::class.java)
                trySend(user)
            } else {
                trySend(null)
            }
        }
        awaitClose { listener.remove() }
    }

    suspend fun getUserOnce(uid: String): User? {
        return try {
            val doc = usersCollection.document(uid).get().await()
            doc.toObject(User::class.java)
        } catch (e: Exception) {
            Log.e("UserRepository", "Error getting user: $uid", e)
            null
        }
    }

    fun getAllUsersFlow(currentUserId: String): Flow<List<User>> = callbackFlow {
        val listener = usersCollection.limit(100).addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.e("UserRepository", "Error fetching all users", error)
                trySend(emptyList())
                return@addSnapshotListener
            }
            val users = snapshot?.documents?.mapNotNull { it.toObject(User::class.java) }
                ?.filter { it.uid != currentUserId }
                ?: emptyList()
            trySend(users)
        }
        awaitClose { listener.remove() }
    }

    suspend fun updatePresence(uid: String, isOnline: Boolean) {
        try {
            usersCollection.document(uid).update(
                mapOf(
                    "isOnline" to isOnline,
                    "lastSeen" to System.currentTimeMillis()
                )
            ).await()
        } catch (e: Exception) {
            Log.e("UserRepository", "Failed to update presence for $uid", e)
        }
    }

    suspend fun updateFcmToken(uid: String, token: String) {
        try {
            usersCollection.document(uid).update("fcmToken", token).await()
        } catch (e: Exception) {
            Log.e("UserRepository", "Failed to update FCM token", e)
        }
    }

    suspend fun uploadProfilePhoto(uid: String, localFile: File): Result<String> {
        return try {
            val ref = storage.reference.child("profile_photos/$uid.jpg")
            ref.putFile(Uri.fromFile(localFile)).await()
            val downloadUrl = ref.downloadUrl.await().toString()
            usersCollection.document(uid).update("photoUrl", downloadUrl).await()
            Result.success(downloadUrl)
        } catch (e: Exception) {
            Log.e("UserRepository", "Failed to upload profile photo", e)
            Result.failure(e)
        }
    }

    fun getPrivacySettingsFlow(uid: String): Flow<PrivacySettings> = callbackFlow {
        val listener = usersCollection.document(uid).collection("settings").document("privacy")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(PrivacySettings())
                    return@addSnapshotListener
                }
                val settings = snapshot?.toObject(PrivacySettings::class.java) ?: PrivacySettings()
                trySend(settings)
            }
        awaitClose { listener.remove() }
    }

    suspend fun updatePrivacySettings(uid: String, settings: PrivacySettings) {
        try {
            usersCollection.document(uid).collection("settings").document("privacy")
                .set(settings, SetOptions.merge())
                .await()
        } catch (e: Exception) {
            Log.e("UserRepository", "Failed to update privacy settings", e)
        }
    }

    suspend fun blockUser(currentUid: String, targetUid: String) {
        try {
            usersCollection.document(currentUid).update("blockedUsers", FieldValue.arrayUnion(targetUid)).await()
            usersCollection.document(currentUid).collection("settings").document("privacy")
                .update("blockedUsers", FieldValue.arrayUnion(targetUid)).await()
        } catch (e: Exception) {
            Log.e("UserRepository", "Failed to block user", e)
        }
    }

    suspend fun unblockUser(currentUid: String, targetUid: String) {
        try {
            usersCollection.document(currentUid).update("blockedUsers", FieldValue.arrayRemove(targetUid)).await()
            usersCollection.document(currentUid).collection("settings").document("privacy")
                .update("blockedUsers", FieldValue.arrayRemove(targetUid)).await()
        } catch (e: Exception) {
            Log.e("UserRepository", "Failed to unblock user", e)
        }
    }

    suspend fun reportUser(currentUid: String, targetUid: String, reason: String) {
        try {
            val report = mapOf(
                "reportedBy" to currentUid,
                "reportedUser" to targetUid,
                "reason" to reason,
                "timestamp" to System.currentTimeMillis()
            )
            firestore.collection("reports").add(report).await()
        } catch (e: Exception) {
            Log.e("UserRepository", "Failed to report user", e)
        }
    }

    suspend fun deleteAccount(uid: String): Result<Unit> {
        return try {
            usersCollection.document(uid).delete().await()
            auth.currentUser?.delete()?.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("UserRepository", "Failed to delete account", e)
            Result.failure(e)
        }
    }
}
